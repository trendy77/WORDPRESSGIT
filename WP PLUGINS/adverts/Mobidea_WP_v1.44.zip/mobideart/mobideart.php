<?php

/**
 * 
 * Plugin Name: Mobidea Redirect Tool
 * Description: This plugin redirects your mobile traffic to a specific website.
 * Version: 1.44
 * Author: Mobidea
 * Author URI:  http://www.mobidea.com
 * Text Domain: mobideart
 * License: GNU General Public License
 * License URI: license.txt
*/

if( !defined('MRT_PLG_VERS') )
    define( 'MRT_PLG_VERS', '1.44' );
if( !defined('MRT_URL') )
    define( 'MRT_URL', plugin_dir_url( __FILE__ ) );

include(dirname(__FILE__) . '/includes/_mobideart_plugin.class.php');
register_activation_hook(__FILE__, array('MobideaRTPlugin', 'install'));
register_deactivation_hook(__FILE__, array('MobideaRTPlugin', 'uninstall'));
add_filter('plugin_action_links', array($MRT,'wp_plugin_links'), 10, 3);
add_action('admin_head', array($MRT, 'wp_admin_head'));
add_action('admin_menu', array($MRT, 'wp_admin_menu'));