1) copy the folder infinityads-ads into wp-content/plugins in your wordpress installation.
2) in your wordpress administration area, navigate to 'Plugins' and click Activate next to the 'Infinityads Ads' plugin entry.
3) Still in the administration pages, navigate to the 'Setting' page, and choose the newly created submenu 'Infinityads Ads Settings'.

