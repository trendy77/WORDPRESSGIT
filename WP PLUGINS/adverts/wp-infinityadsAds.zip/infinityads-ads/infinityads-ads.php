<?php
/**
 * Plugin Name: Infinityads Ads
 * Plugin URI: http://www.infinityads.com/
 * Description: Use this plugin to earn money by showing infinityads.com ads
 * Version: 1.0
 * Author: Infinityads Publisher Team
 * Author URI: http://www.infinityads.com/
 */
 
define('INFINITYADS_ADS_VERSION', '1.0');
define('INFINITYADS_ADS_DEBUG', false);

class InfinityadsAds {

	/**
	 * Add option page to menu
	 */
	function admin_menu() {
		add_options_page(__('Infinityads Ads'), __('Infinityads Ads'), 'manage_options', str_replace("\\", "/", __FILE__), array('InfinityadsAds', 'options'));
	}

	/**
	 * This is used to display the options page for this plugin
	 */
	function options() {
		/**
		 * @var WP_Roles
		 */
		//global $wp_roles;

		//Get our options
		$infinityads_options = InfinityadsAds::get_options();
		//Echo debug info if needed
		if (INFINITYADS_ADS_DEBUG) {
			echo '<pre>',var_dump($infinityads_options),'</pre>';
		}

		/*
		//We will fill $roles with checkboxes to ignore each role
		$roles = '';
		foreach ($wp_roles->roles as $role=>$role_info) {
			$checked = (isset($role_info['capabilities']['wga_no_track']) && $role_info['capabilities']['wga_no_track'])? ' checked="checked"':'';
			$role_info['name'] .= (strtolower(substr($role_info['name'], -1)) != 's')? 's':'';
			$roles .= "					<label for='wga_role_{$role}'><input type='checkbox' name='wga-roles[{$role}]' value='true' id='wga_role_{$role}'{$checked} /> ".__("Do not log {$role_info['name']} when logged in")."</label><br />";
		}
		*/
?>
		<div class="wrap">
			<h2><?php _e('Infinityads Ads Options') ?></h2>
			<form action="options.php" method="post" id="wp_infinityads_ads">
				<?php wp_nonce_field('update-options'); ?>
				<p>Enter publisher ID and site ID below. If you don't have an account, register at <a href="http://www.infinityads.com" target="_blank">http://www.infinityads.com</a></p>
				<table class="form-table">
					<tr valign="top">
						<th scope="row">
							<label for="infinityads_nid"><?php _e('Infinityads publisher ID:'); ?></label>
						</th>
						<td>
							<input type="text" name="infinityads[nid]" id="infinityads_nid" readonly size="2" maxlength=3 value="<?php echo 5;//$infinityads_options['nid']; ?>" onkeyup="if(this.value.length>2) document.getElementById('infinityads_pubid').focus()" />-P-<input type="text" name="infinityads[pubid]" id="infinityads_pubid" size="10" value="<?php echo $infinityads_options['pubid']; ?>" />
						</td>
					</tr>
					<tr valign="top">
						<th scope="row">
							<label for="infinityads_sid"><?php _e('Site ID:'); ?></label>
						</th>
						<td>
							<input type="text" name="infinityads[sid]" id="infinityads_sid" size="10" value="<?php echo $infinityads_options['sid']; ?>"  /> <a href="http://member.infinityads.com/images/siteid.jpg" target="_blank">Help?</a>
						</td>
					</tr>

					<tr valign="top">
						<th scope="row">
							<label for="infinityads_textlink"><?php _e('Display Inline Text Link Ad:'); ?></label>
						</th>
						<td>
							<input type="checkbox" id="infinityads_textlink" name="infinityads[textlink]" value="1" style="margin-top: 7px;" <?php echo $infinityads_options['textlink']||!isset($infinityads_options['pubid'])?"checked":""; ?> /> 
						</td>
					</tr>

					<tr valign="top">
						<th scope="row">
							<label for="infinityads_connect"><?php _e('Enable Connect Widget:'); ?></label>
						</th>
						<td>
							<input type="checkbox" id="infinityads_connect" name="infinityads[connect]" value="1" style="margin-top: 7px;" <?php echo $infinityads_options['connect']||!isset($infinityads_options['pubid'])?"checked":""; ?> /> 
						</td>
					</tr>

					<tr valign="top">
						<th scope="row">
							<label for="infinityads_popunder"><?php _e('Display Pop-under Ad:'); ?></label>
						</th>
						<td>
							<input type="checkbox" id="infinityads_popunder" name="infinityads[popunder]" value="1" onclick="if(this.checked){ document.getElementById('pop_settings').style.display='block'; }else{ document.getElementById('pop_settings').style.display='none';}" style="margin-top: 7px;" <?php echo $infinityads_options['popunder']||!isset($infinityads_options['pubid'])?"checked":""; ?> /> 
							<br /><br />
							<div id="pop_settings" style="<?php echo $infinityads_options['popunder']?"display:block":"display:none"; ?>">
								Frequency Cap: No more than 1 pop-under Ad per <select class="inputbox" name="infinityads[cap]">
																				<option value="-1" <?php echo $infinityads_options['cap']=='-1'?"selected":""?>>No Frequency Cap</option>
																				<option value="0" <?php echo $infinityads_options['cap']=='0'?"selected":""?>>1 pop per session</option>
																				<option value="0.1" <?php echo $infinityads_options['cap']=='0.1'?"selected":""?>>6 mins</option>
																				<option value="0.2" <?php echo $infinityads_options['cap']=='0.2'?"selected":""?>>12 mins</option>
																				<option value="0.3" <?php echo $infinityads_options['cap']=='0.3'?"selected":""?>>18 mins</option>
																				<option value="0.5" <?php echo $infinityads_options['cap']=='0.5'?"selected":""?>>30 mins</option>
																				<option value="1" <?php echo $infinityads_options['cap']=='1'?"selected":""?>>1 hr</option>
																				<option value="2" <?php echo $infinityads_options['cap']=='2'?"selected":""?>>2 hrs</option>
																				<option value="3" <?php echo $infinityads_options['cap']=='3'?"selected":""?>>3 hrs</option>
																				<option value="4" <?php echo $infinityads_options['cap']=='4'?"selected":""?>>4 hrs</option>
																				<option value="6" <?php echo $infinityads_options['cap']=='6'?"selected":""?>>6 hrs</option>
																				<option value="8" <?php echo $infinityads_options['cap']=='8'?"selected":""?>>8 hrs</option>
																				<option value="10" <?php echo $infinityads_options['cap']=='10'?"selected":""?>>10 hrs</option>
																				<option value="12" <?php echo $infinityads_options['cap']=='12'?"selected":""?>>12 hrs</option>
																				<option value="24" <?php echo $infinityads_options['cap']=='24'?"selected":""?>>1 Day</option>
																				<option value="48" <?php echo $infinityads_options['cap']=='48'?"selected":""?>>2 Day</option>
																				<option value="720" <?php echo $infinityads_options['cap']=='720'?"selected":""?>>1 Month</option>
																			  </select>

								<br />
								<input type="checkbox" id="infinityads_layer_pop" name="infinityads[layerpop]" value="1" <?php echo $infinityads_options['layerpop']||!isset($infinityads_options['pubid'])?"checked":""; ?> /> <label for="infinityads_layer_pop">Enable Layer Pop Ad.</label>
							</div>
						</td>
					</tr>
				</table>
				<p class="submit">
					<input type="submit" name="Submit" value="<?php _e('Update Options &raquo;'); ?>" />
				</p>
				<input type="hidden" name="action" value="update" />
				<input type="hidden" name="page_options" value="infinityads" />
			</form>
		</div>
<?php
	}

	

	/**
	 * Inject code to the footer
	 */
	function adsScript() {
		if(self::validateSavedInfo()){
			$infinityads_options = InfinityadsAds::get_options();
?>

<script type="text/javascript">
//Ad here widget
infinityads_enable_adhere = <?php echo $infinityads_options['connect']?"true":"false" ?>;
//default pop-under house ad url
infinityads_enable_pop = <?php echo $infinityads_options['popunder']?"true":"false" ?>; infinityads_frequencyCap = <?php echo $infinityads_options['cap']?$infinityads_options['cap']:0 ?>;
durl = '';infinityads_layer_border_color = '';
infinityads_layer_ad_bg = ''; infinityads_layer_ad_link_color = '';
infinityads_layer_ad_text_color = ''; infinityads_text_link_bg = '';
infinityads_text_link_color = ''; infinityads_enable_text_link = <?php echo $infinityads_options['textlink']?"true":"false" ?>;
<?php echo ($infinityads_options['popunder'] && $infinityads_options['layerpop'])?"":"infinityads_enable_layer_pop = false;" ?>
</script>
<script type="text/javascript" src="http://ads.lzjl.com/newServing/showAd.php?nid=<?php echo intval($infinityads_options['nid']=="100"?"1":$infinityads_options['nid']);?>&amp;pid=<?php echo intval($infinityads_options['pubid']);?>&amp;adtype=&amp;sid=<?php echo intval($infinityads_options['sid']);?>"></script>
<noscript><a href="http://www.infinityads.com">online advertising</a></noscript>


<?php			
		}
		
	}

	/**
	 * Get option values
	 */
	function get_options($option = null) {
		$o = get_option('infinityads');
		if (isset($option)) {
			if (isset($o[$option])) {
				return $o[$option];
			} else {
				return false;
			}
		} else {
			return $o;
		}
	}

	
	
	function warning(){
		
		if(!self::validateSavedInfo()){
			$setting_url = admin_url( 'options-general.php?page=infinityads-ads/infinityads-ads.php' );
			echo "<div id='message' class='error'><p><strong>Infinityads ads is not active.</strong> You must <a href='".$setting_url."'>enter required account information</a> before it can work.</p></div>";
		}
	}
	
	function validateSavedInfo(){
		$infinityads_options = InfinityadsAds::get_options();

		if ((!isset($infinityads_options['pubid']) || empty($infinityads_options['pubid'])) 
				|| (!isset($infinityads_options['sid']) || empty($infinityads_options['sid'])) 
				|| (!$infinityads_options['textlink'] && !$infinityads_options['popunder'] && !$infinityads_options['connect'])) 
			return false;
		return true;

	}
	
	function add_action_link( $links, $file ) {
		if (preg_match('/infinityads/', $file)){
			$settings_link = '<a href="' . admin_url( 'options-general.php?page=infinityads-ads/infinityads-ads.php' ) . '">' . __('Settings') . '</a>';
			array_unshift( $links, $settings_link );
		}
		return $links;
	}
}



/**
 * Add the hooks
 */
 
function infinityads_activate() {
	add_option('infinityads_version', INFINITYADS_ADS_VERSION);
 }
function infinityads_deactivate() {
	delete_option('infinityads_version');
}


register_activation_hook( __FILE__, 'infinityads_activate' );
register_deactivation_hook( __FILE__, 'infinityads_deactivate' );


add_action('admin_menu', array('InfinityadsAds','admin_menu'));
add_filter('plugin_action_links', array('InfinityadsAds', 'add_action_link'), 10, 2 );
add_action('get_footer', array('InfinityadsAds', 'adsScript'),100);
add_action('admin_footer', array('InfinityadsAds','warning'));
?>
