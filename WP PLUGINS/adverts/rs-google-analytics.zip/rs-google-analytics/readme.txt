=== RS Google Analytics ===
Tags: Google, Analytics, Google Analytics, UA, UA Code, Code
Requires at least: 3.8
Tested up to: 4.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows you to add your UA code to your website

== Description ==

Allows you to add your UA code to your website.

You can specify whether you want the code to be added to the footer or the header of your site.

== Installation ==

1. Upload `rs-google-analytics` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==



== Screenshots ==
1. Simply add your UA code


== Changelog ==

= 1.0.1 =
* Testing for 4.0, minor bug fix

= 1.0 =
* First version of plugin

== Upgrade Notice ==