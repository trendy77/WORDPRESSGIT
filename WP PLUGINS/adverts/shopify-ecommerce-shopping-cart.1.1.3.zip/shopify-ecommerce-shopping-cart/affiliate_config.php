<?php
  // set your affiliate code here i.e. awesome-partner
  define('AFFILIATE_CODE', '');
?>
