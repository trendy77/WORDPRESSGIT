<?php

/*
  Plugin Name: AJAX Plugin for AdSense
  Plugin URI: http://www.thulasidas.com/adsense
  Description: <em>Lite Version</em>: Easiest way to show AdSense and make money from your blog. Configure it at <a href="options-general.php?page=wp-google-adsense.php">Settings &rarr; Easy AdSense Lite</a>.
  Version: 9.10
  Author: Manoj Thulasidas
  Author URI: http://www.thulasidas.com
 */

/*
  Copyright (C) 2008 www.ads-ez.com

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 3 of the License, or (at
  your option) any later version.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


require_once 'wp-google-adsense.php';