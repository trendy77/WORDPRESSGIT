<?php

require_once('../../EzGA.php');

EzGA::update();
