=== Remove Yoast SEO comments ===
Contributors: lowest
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2VYPRGME8QELC
Tags: yoast seo, yoast, seo, remove comments, remove html, remove ads, remove debug code, lightweight
Requires at least: 1.2.0
Stable tag: 1.2.0
Tested up to: 4.7

Removes the Yoast SEO advertisement HTML comments from your front-end source code.

== Description ==

A light-weight plugin which will remove the advertisement HTML comments coming from the Yoast SEO plugin, such as:

`<!-- This site is optimized with the Yoast SEO plugin -->`

This is a must-have plugin if you have Yoast SEO or Yoast SEO Premium installed.

= Note =
This plugin requires [Yoast SEO](http://wordpress.org/plugins/wordpress-seo/) or Yoast SEO Premium. If you do not have Yoast SEO or Yoast SEO Premium activated, this plugin will not work.

= Like this plugin? =
If you like this plugin, make sure to rate it 5 stars. Also check out [Remove Google Analytics comments](https://wordpress.org/plugins/remove-google-analytics-comments/)!

== Installation ==

1. Upload the 'remove-yoast-seo-comments' folder to the /wp-content/plugins/ directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. All done! The HTML comments are now removed from your front-end source code.

== Frequently Asked Questions ==

= When Yoast SEO updates their plugin, will the HTML comments stay removed? =

Yes, they will stay removed as long as Yoast does not change any file names.

= Does this plugin add any configuration options? =

No, activate the plugin and you are done! This plugin will not add any extra tables or such to your database.

= Will this plugin modify any of my Yoast SEO plugin files? =

No, this plugin will not modify any of your Yoast SEO plugin files.

== Changelog ==

= 1.0.5 =
* Fixed an security vulnerability regarding `target="_blank"` ([read more](https://core.trac.wordpress.org/ticket/36809))
* Added support for WordPress 4.7

= 1.0.4 =
* Removed debugging code

= 1.0.3 =
* Removed anonymous functions: RYSC is now more light-weight than ever

= 1.0.2 =
* Minor changes to all files
* Removed a unnecessary file

= 1.0.1 =
* Added support for Yoast SEO Premium

= 1.0 =
* Initial release