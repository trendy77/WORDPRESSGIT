<?php die( 'These aren\'t the droids you\'re looking for...' );
// extract of translatable text strings from static config array(s)
_x( 'Alpha and Up', 'option value', 'wpsso-um' );
_x( 'Beta and Up', 'option value', 'wpsso-um' );
_x( 'Development and Up', 'option value', 'wpsso-um' );
_x( 'Every day', 'option value', 'wpsso-um' );
_x( 'Every five days', 'option value', 'wpsso-um' );
_x( 'Every four days', 'option value', 'wpsso-um' );
_x( 'Every month', 'option value', 'wpsso-um' );
_x( 'Every six days', 'option value', 'wpsso-um' );
_x( 'Every three days', 'option value', 'wpsso-um' );
_x( 'Every three weeks', 'option value', 'wpsso-um' );
_x( 'Every two days', 'option value', 'wpsso-um' );
_x( 'Every two weeks', 'option value', 'wpsso-um' );
_x( 'Every week', 'option value', 'wpsso-um' );
_x( 'Release Candidate and Up', 'option value', 'wpsso-um' );
_x( 'Stable / Production', 'option value', 'wpsso-um' );
_x( 'Update Manager', 'lib file description', 'wpsso-um' );
_x( 'WPSSO extension to provide updates for the WordPress Social Sharing Optimization (WPSSO) Pro plugin and its Pro extensions.', 'plugin description', 'wpsso-um' );
?>
