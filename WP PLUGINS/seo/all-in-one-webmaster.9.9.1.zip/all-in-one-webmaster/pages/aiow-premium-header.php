<?php
/**
 * @author Crunchify.com
 * Plugin: All in One Webmaster
 * URL: http://crunchify.com/all-in-one-webmaster/
 */
?>

<div class=wrap>

	<form method="post" action="<?php echo $_SERVER["REQUEST_URI"]; ?>">
		<input type="hidden" name="info_update1" id="info_update1"
			value="true" /> <u><h2>All in One Webmaster Options</h2></u>

		<div align="left">
			<br> <a href="https://twitter.com/Crunchify"
				class="twitter-follow-button" data-show-count="false">Follow
				@Crunchify</a>
			<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
			<div id="fb-root"></div>
			<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.4";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

			<div class="fb-like" data-href="https://www.facebook.com/Crunchify"
				data-layout="standard" data-action="like" data-show-faces="false"
				data-share="true"></div>
		</div>

		<div id="poststuff" class="metabox-holder has-right-sidebar">

			<div style="float: left; width: 70%;">

				<br>