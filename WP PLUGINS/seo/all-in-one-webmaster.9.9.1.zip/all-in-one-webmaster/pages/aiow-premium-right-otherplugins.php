<?php
/**
 * @author Crunchify.com
 * Plugin: All in One Webmaster
 */
?>

<br>
<div id="side-info-column" class="inner-sidebar">
	<div class="postbox">
		<h3 class="hndle">
			<span>List of All Features</span>
		</h3>

		<div class="inside">
			<ul>
				<li>1) Analytics Options</li>
				<li>2) Webmaster Options</li>
				<li>3) Google Authorship Options</li>
				<li>4) Header / Footer Section</li>
				<li>5) Misc Options - Add Global Site Favicon Option</li>
				<li>6) Sitemap submission to Google / Bing Webmaster</li>
			</ul>
		</div>
	</div>
</div>