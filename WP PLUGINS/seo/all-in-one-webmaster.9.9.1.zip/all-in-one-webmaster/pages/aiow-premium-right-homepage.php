<?php
/**
 * @author Crunchify.com
 * Plugin: All in One Webmaster
 */
?>

<br>
<div id="side-info-column" class="inner-sidebar">
	<div class="postbox">
		<h3 class="hndle">
			<span>Now with few Premium Features</span>
		</h3>

		<div class="inside">
			<ul>
				<div align="left">
					<a href="http://crunchify.com/all-in-one-webmaster/"
						target="_blank">More Info...</a>
				</div>
			</ul>
		</div>
	</div>
</div>