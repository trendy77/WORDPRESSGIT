<?php
/**
 * @author Crunchify.com
 * Plugin: All in One Webmaster
 */
?>

<?php
require_once 'aiow-premium-right-homepage.php';
require_once 'aiow-premium-right-otherplugins.php';
?>
