<?php
/**
 * @author Crunchify.com
 * Plugin: All in One Webmaster
 * URL: http://crunchify.com/all-in-one-webmaster/
 */
?>

</div>

<div class="clear">
	<p>
		<br />&copy; Copyright 2012 - <?php echo date("Y"); ?> <a
			href="http://Crunchify.com" target="_blank">Crunchify.com</a>
	</p>
</div>
