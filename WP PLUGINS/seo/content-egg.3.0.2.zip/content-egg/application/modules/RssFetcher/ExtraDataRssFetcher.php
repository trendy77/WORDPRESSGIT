<?php

namespace ContentEgg\application\modules\RssFetcher;

use ContentEgg\application\components\ExtraData;

/**
 * ExtraDataRssFetcher class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2015 keywordrush.com
 */
class ExtraDataRssFetcher extends ExtraData {

    public $allData = array();

}
