<?php

namespace ContentEgg\application\modules\Offer;

use ContentEgg\application\libs\ParserClient;

/**
 * OfferParser class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link http://www.keywordrush.com/
 * @copyright Copyright &copy; 2016 keywordrush.com
 *
 */
class OfferParser extends ParserClient {
    
    

}
