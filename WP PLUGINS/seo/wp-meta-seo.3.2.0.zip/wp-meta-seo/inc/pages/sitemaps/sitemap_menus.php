<h1><?php _e('Sitemap','wp-meta-seo') ?></h1>
<h2 class="nav-tab-wrapper">
    <div class="nav-tab nav-tab-active" data-tab="sitemaps"><?php _e('Sitemaps','wp-meta-seo') ?></div>
    <div class="nav-tab" data-tab="menu"><?php _e('Source: menu','wp-meta-seo') ?></div>
    <div class="nav-tab" data-tab="posts"><?php _e('Source: posts','wp-meta-seo') ?></div>
    <div class="nav-tab" data-tab="pages"><?php _e('Source: pages','wp-meta-seo') ?></div>
</h2>