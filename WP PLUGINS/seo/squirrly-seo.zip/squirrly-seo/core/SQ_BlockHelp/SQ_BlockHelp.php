<?php

/**
 * Affiliate settings
 */
class SQ_BlockHelp extends SQ_BlockController {

}
