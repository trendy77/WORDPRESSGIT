<?php

class SQ_BlockAnalytics extends SQ_BlockController {

    public function hookGetContent() {

    }

}
