<?php

/**
 * Class for Traffic Record
 */
class SQ_Traffic extends SQ_FrontController {

}
