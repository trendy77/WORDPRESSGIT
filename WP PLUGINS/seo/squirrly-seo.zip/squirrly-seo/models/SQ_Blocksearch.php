<?php

/**
 * The model class for SQ_Blocksearch
 *
 */
class Model_SQ_Blocksearch {


}
