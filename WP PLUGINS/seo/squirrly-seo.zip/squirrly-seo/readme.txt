﻿=== SEO by SQUIRRLY™ ===
Contributors: calinvingan, florinmuresan, nagy.sorel
Tags: seo,seo plugin,apps,wordpress seo,seo optimization,seo content,plugin,content seo,search engine optimization,xml,sitemap,keyword,keyword research,post,posts,page,multisite,squirrly,wordpress,tag,image,images,photos,flickr,statistics,stats,google,content,title,description,favicon,mobile,canonical,author,google plus,analytics,admin,seo correction,seo title,seo meta,meta,google,twitter,news,blog,e-commerce,ecommerce,woocommerce,feed,feeds,marketing,buddypress,social,social media,url,automatic,iphone,administration,analytics,blogging,categories,comment,dashboard,free,google-analytics,linkedin,list,media,optimization,performance,pinterest,plugins,products,share,sharing,tags,tracking,traffic,tweet
Requires at least: 3.5    
Tested up to: 4.6
Stable tag: trunk  
Donate link: https://www.squirrly.co/wordpress-seo-by-squirrly      
   
SEO Plugin By Squirrly is for the NON-SEO experts. Get Excellent SEO with Better Content, Ranking and Analytics. For Both Humans and Search Bots.
        
== Description ==    
SEO By Squirrly helps you write content that is SEO friendly and ALSO Human friendly. You'll get to improve your rankings, while providing your readers with great content. See Your SEO Stats, get a weekly SEO Audit and find the best keywords.
 
It works well with Wordpress sites that already have <strong>Yoast</strong> or <strong>All In One SEO</strong>. You can opt-in to keep those settings, so no need to start over again :-)

Recommended by <strong><a href="http://www.quicksprout.com/university/how-to-maximize-your-seo-traffic-with-these-must-have-wordpress-plugins/" >Neil Patel</a></strong>, the co-founder of Kissmetrics and Crazy Egg. Also by <strong>Brian Dean</strong> and over 100 content marketing experts

[youtube https://www.youtube.com/watch?v=mEjrE7TuDDc]

See all the Squirrly SEO 2016 features at: http://howto.squirrly.co/category/sides/

Based on the topic you're writing about, the interface will light up green while you're editing your text, so that you know you've done something right. When all the lights are green, you can publish it, because your text has excellent SEO and it's 100% optimized.

Different customers, from areas such as e-commerce, law firms, digital agencies, online magazines, movie review sites, etc. have reported +285% increase in the number of readers, by optimizing their content with this seo plugin, and by measuring and improving as advized by our tool. 

All-In-All: Squirrly SEO will help you get a tool that acts like an Expert Consultant, sitting right next to you, advising on SEO, and telling you where you need to improve.

The best things is: YOU DON'T have to be an SEO expert to use it. Wait, you don't even need to know about all that. Squirrly will help you write great content, will show you where your Wordpress needs improvements and it will even help you learn all about content marketing and seo strategies through email trainings.

Squirrly SEO is a Freemium software, like MailChimp.

You’ll start with the free version of Squirrly SEO. It will help you if you have small content marketing needs, such as 5 articles published / month, 5 keyword analysis and a weekly audit report. When you'll require more, you can pay for the PRO Plan.

-<strong>Gives You SEO Advice as you're typing your articles.</strong> Squirrly helps you in real time to optimize your articles to 100%, while you are writing or editing them.

- <strong>Green lights turn on everytime you do something right.</strong> When all the lights turn green, you can publish or schedule the article because it has excellent seo.

- <strong>Optimized articles get +285% traffic,</strong> on average (real statistics from over 16,500 people who participated in the survey).

- <strong>SEO Settings remain</strong>. If you already made your SEO settings for WordPress with other plugins, you can keep using those and Squirrly won't override them. No need to start all over. We'd hate to have you do that.

- <strong>Finds you Keywords and Topics that your Customers actively search for</strong> and which will help you out-rank your competitors, not just follow them around the serps

- <strong>The algorithm for Keyword analysis</strong> takes into accounts elements that will help you find suitable keywords for content optimization: for Humans and for Search Engines.

- <strong>Tracks all the aspects of your Content Marketing Strategy:</strong> Blogging, Traffic, SEO, Social Signals, Links, Authority. Every single week you get a new report by email.

- <strong>Send the Audit report by email</strong> to your content writer, SEO person, developers, or to your boss.

- <strong>It Gives You Professional Advice on How To Fix</strong> any of those areas that it helps track, so you can easily find out how to improve. Content from SEO Moz (recently just MOZ), Google, Authority Labs, etc.

- <strong>Monitors Your Progress, week by week.</strong> You'll get interesting data about the historical performance of each article you write and find out how to improve its seo ranking.

- <strong>Analyze any single article. See how it improves over time.</strong>

- <strong>Optimize Your Content for Humans.</strong> We've recently added tools and lessons (free of charge) that will help you optimize all of your Content for Humans, not just for search engines.

- <strong>Write Better Content.</strong> We help you build up seo content that is also great-to-read for Human readers and helps you build up some valuable and subtle SEO.

- <strong>Stay up to date with your SEO and Social Signals, with our Email Alerts</strong>. We send out email alerts if something on your Wordpress site needs immediate attention, so that you can act upon it and save your business the trouble.

- <strong>Copyright-Free Images That You Can Use.</strong>

- <strong>Headline Suggestions based on your SEO keyword.</strong>

- <strong>Social Intelligence through the Inspiration Box, to help you write better content. Shows you recent tweets about your subject, how other journalists and bloggers have approached your topic. All of this in your "Add New Post" interface.</strong>

You can use Squirrly SEO for FREE and if you have small content marketing needs (about one article posted per week, some keywords that you want to analyze), then it's the perfect plan for you.

Once you start having bigger content marketing and SEO needs (more than one article posted per week), you can go PRO. Read more about it in the FAQ section.

<h3>Reviews</h3>

* <em>"Wow, I've been using your tool for a week now and one of my blog ranked no1 out of a million for its key word... amazing"</em>

* <em>"You can be confident that without ever leaving your Add New Blog page you have a strong keyword, good and current content, and your post will be 100% optimized for the search engines."</em> - <strong>Jason Fox Marketing</strong>

* <em>"Features that exceed the stereotypical plugin"</em> - <strong>Robert, Yieldkit</strong>

* <em>"It's amazing! Seeing a huge boost in traffic"</em>

* <em>"Great SEO info at a click"</em>

<strong>You can read reviews from Internet Marketing experts on http://howto.squirrly.co/testimonials/</strong>

Over 1,600,000 Downloads. Our startup consists of 10 content marketing professionals dedicated to making Squirrly an amazing piece of software and writing great training materials to help you be successful and stay successful.

Over 860 Content Marketing Experts have reviewed our Wordpress SEO plugin and loved it.

Over 2580 students to our $147 Content Marketing Training on Udemy. Part of that training you'll be receiving for free when signing up for this Wordpress seo plugin.

over +285% increase in traffic to over 49,000 survey participants.

Recently our team grew to 20 people. More than helping you with your internet marketing efforts, we strive to offer Excellence in Customer Service.

* we have a Free Training session with 14 lessons and 10 actionable work files, awaiting you after you install the plugin and connect to squirrly.co (you'll receive them by email)

* you'll be able to get support from us from the plugin, from our Facebook, our Twitter, email and we can even schedule a Skype call, if fixes are needed

We're passionate about seeing you get a great and happy experience, so we'll do our best to fix anything that may come up very fast.

The <a title="Squirrly SEO in Delivering Happiness" href="http://www.deliveringhappiness.com/everyday-happiness-florin-squirrly-and-how-theyre-making-happy-work/" target="_blank">Delivering Happiness</a> blog featured us for this.

We're glad to have you,
Florin Muresan
CEO of Squirrly

See all the Features of our product on the <a href="http://howto.squirrly.co/category/sides/" title="Squirrly WordPress SEO"> All Squirrly SEO Features </a>.

<a href="/extend/plugins/squirrly-seo/screenshots/" title="Squirrly SEO Plugin">Check our screenshots</a>
 | <a href="http://howto.squirrly.co/" title="Squirrly SEO" target="_blank">Go to our official site</a> | Free Version (if you install from the WP directory) OR <a href="http://howto.squirrly.co/squirrly-pricing-plans/" title="See Pricing" target="_blank">Pricing Plans</a>

== Installation ==
1. Log In as an Admin on your WordPress blog.
2. In the menu displayed on the left, there is a "Plugins" tab. Click it.
3. Now click "Add New".
4. There, you have the buttons: "Search | Upload | Featured | Popular | Newest". Click "Upload".
5. Upload the squirrly-seo.zip file.
6. After the upload is finished, click Activate Plugin.
7. Good. Now enter your email to connect with Squirrly.co
8. Then click "Write a New Post with Squirrly Seo".
9. Done. Start getting Excellent SEO on Wordpress
10. The Email Lessons will help you become a great content marketer. Our content Marketing Class on Udemy has over 600 students and the price is $147. You're getting all that for free, by email.

Type a keyword to the right of the screen and start using Squirrly Seo. Enjoy!

== Screenshots ==
1. Seo - Optimize your article with SEO Live Assistant
2. Seo - Find the top keywords with the Keyword Researh
3. Seo - Customize the META with the SEO Snippet
4. Seo - Find your top posts and authors with Squirrly Analytics
5. Seo - Monitor your success with the Performance Analytics
6. Seo - Let Squirrly do the SEO Settings that your blog needs
7. Seo - Check your Weekly Site Audit and improve to get higher scores

== Upgrade Notice ==
Squirrly 5.2.8 it's a stable version of Squirrly SEO and has all the SEO requirements by Search Engines

== Changelog ==
= 6.2.4 =
* Fixed bug for Google Analytics AMP version
* Fixed both title and description when include price value

= 6.2.3 =
* Added Open Graph Image for First Page when the first page is a blog feed
* Fixed small css issues in post editor
* Fixed duplicate title removal
* Added AMP Analytics from Google

= 6.2.2 =
* Compatible with WP 4.6.1
* Fixed SEO Page Optimization for Post Feed Page and Home Page
* Update SEO features

= 6.2.0 =
* Added Facebook Pixel Tracking Code in Squirrly > SEO > Tracking
* Added more Copyright Free images in Squirrly SEO Live Assistant from:
* Pixabay.com
* Unsplash.com
* Pexels.com
*
* Fixed loading the Seo Live Assistant when a page is not optimized for a keyword
* Fixed the connection issues between the plugin and API when a post is saved
* Fixed the Squirrly Snippet when connected as Editor or Author4


= 6.1.6 =
* Added custom title and description for the Posts Page in Settings > Reading > Posts page
* Fixed the JsonLD phone + prefix
* Fixed typos

= 6.1.5 =
* July 2016 Security updates.
* Fixed vulnerabilities between users who have rights in you site
* Fixed some Squirrly SEO Snippet issues on first save
* Added google.co.id in Rank Option

= 6.1.3 =
* Rich Pins Validator Option
* Added rich pins for Woocommerce Products

= 6.1.2 =
* Compatible with WP 4.5.3
* Fixed the google profile link
* Corrected some old links
* We moved js files on cloud for faster loading
* Update Rank Check to the latest Google Requirements

= 6.1.0 =
* Compatible with WP 4.5.2
* Fixed the Front Page SEO to work with more WP themes
* Fixed compatibility with PolyLang plugin
* Fixed compatibility with Customizr theme
* Fixed Squirrly SEO Snippet for arabic lang

= 6.0.9 =
* Compatible with WP 4.5
* Fixed Squirrly Analaytics in Performance Analytics

= 6.0.6 =
* Update the Squirrly SEO Snippet
* Fixed the Json AMP for articles
* Added dateModified, ImageObject, mainEntityOfPage, publisher

= 6.0.4 =
* Fixed the snippet to save long text
* Fixed the woocommerce title and description for a category
* Fix the SEO for more themes

= 6.0.3 =
* Fixed compatibility with NextGen Gallery plugin
* Compatible with 4.4.3

= 6.0.2 =
* Added style for the site feed in Squirrly > SEO
* Fixed the hook for feed when Squirrly SEO sitemap is active
* Fixed the SEO for more WP themes

= 6.0.0 =
* The last stable version of Squirrly with all the features included:
* Squirrly SEO is compatible with more WP themes
* Twitter Card latest updates  (summary and summary_large_image)
* Open Graph updates (multiple images, videos)
* Sitemap with more video like Wistia.com, FLV
* External Canonical Link
* Woocommerce & Instapage compatility
* Compatible with WP 4.4.1

= 5.3.1 =
* Added the Twitter Summary Type option in Squirrly > SEO > Twitter Card
* Fixed the same Title SEO issues for some WP themes
* Fixed small bugs

= 5.2.9 =
* Optimized the way SEO is loading in every page
* Optimized SEO for Instapage Plugin
* Updated the Google Analytics Tracking code
* Fixed the compatibility issue in Performance Analytics
* Added twitter summary for large images

= 5.2.7 =
* Added Squirrly SEO Canonical Link in Post Edit page
* Added Norway country in Google Rank Option
* Set the Squirrly SEO Snippet OG image as shared image
* Set Squirrly SEO Live Assistant to work with more multilanguage plugins
* Fixed the images in Squirrly Inspiration Box

= 5.2.6 =
* Compatible with Smart Security Tools plugin
* Added the google.ee in Squirrly Rank Option
* Fixed the Squirrly SEO Keyword not to be added in Tags if is switched off in Squirrly > Settings

= 5.2.5 =
* Improved the Squirrly SEO Keyword Research
* Fixed the sitemap.xml with videos included
* Changed to relative url in sitemap.xml for multisites

= 5.2.3 =
* Compatible with Wordpress 4.3.1
* Fixed the Seo Live Assistant to verify keywords with commas
* Fixed the Seo Live Assistant to work with HTTPS dashboard for Wikis and Keyword suggestion
* Fixed the OG:image:width issue when the width is null
* Fixed the HTTPS connection when the general settings are not set correctly
* Fixed minor bug
* Updated to the last on-page SEO requirements
* Increased the Squirrly speed in post editor


= 5.2.2 =
* Add the last google updates for JSON-LD Structured Data
* Make sitemap.xml work for a large number of articles

= 5.2.1 =
* Compatible with Wordpress 4.3
* Fixed the Head Buffer for some themes

= 5.2.0 =
* Compatible with Wordpress 4.2.4
* Added 17 more languages in Squirrly SEO Keyword Research
* Added the focused language for Social Media in Squirrly > SEO
* Added Squirrly SEO Performance Analytics in custom post types selected from Squirrly SEO > Settings
* Add top menu link for Rank check

= 5.1.6 =
* Compatible with WP 4.2.3
* Improved the rank check to prevent Google temporary IP block
* Improved the plugin speed in backend
* Fixed the Incorrect Hreflang META implementation
* Add the optimization progress bar in the post/page list
* Fixed the restore the settings from backup validator

= 5.1.2 =
* Added new features in Open Graph for the Posts/Pages
* Added the SEO Settings Backup and Restore
* Improved the SEO Live Assistant to recognize more languages and chars
* Improved the communication with the API Server
* Fixed the Analytics notification bar
* Fixed the wp_is_writable for older wp versions
* Fixed the Open Graph not to include non embed videos in meta
* Fixed the Sitemap Ping option to remain switched on when is selected
* Added the custom size image for Open Graph in Squirrly SEO Snippet

= 5.0.3 =
* Prevent canonical, prev, next meta duplicate inserted by other SEO plugins
* Fixed snippet custom title and description to change when other SEO plugins are installed
* Fixed javascript issue in login page

= 5.0.0 =
* Changed Squirrly SEO look
* Compatible with WP eCommerce plugin
* Made SEO improvements for Woocommerce plugin
* Interactive learning for the entire Squirrly SEO plugin
* Faster post save for long text and remote images
* Settings and SEO check improved
* Added robots.txt for multisites with security
* Added sitemap for multisites
* Added sitemap for images and videos for each article
* Added the Json LD in Structured Data META
* Added the social linked Data for Json LD and publisher
* Added the favicon.ico for multisites
* Added the icos for apple devices
* Added the SEO progress in post editor
* Added the SEO Star option in Dashboard
* Fixed bugs for multisites and made it compatible with WP 4.2
* Fixed the snippet title and description special chars
* Fixed the custom fields variable in post editor
* Fixed the site icon and added the site icon for multisites
* Fixed Sitemap for default permalink option
* Fixed the SEO Analytics and the Rank updates
* Fixed the SEO for First Page  if the Home Page is not a static page
* Fixed the SEO for the First Page when it starts with woocommerce shop


== Credits ==
* Florin Muresan - CEO at Squirrly
* Calin Vingan - CTO at Squirrly
* Sorel Nagy - Developer
* Andreea Leau - VP Marketing
* Cristina Leau  - Squirrly mascot designer
* Alexandra Nicola - COO
* Teodora Vingan - SEO Analyser
* Tim - Content Writer
* Olivia Barbu - Content Writer
* Alex Iftode - Content Writer
* Irina Pogor - Content Writer
* Ana Darstaru - Chief of Customer Service
* Lucian Nertan - VP of Agency

== Investors ==
* Ibrahim Evsan, serial entrepreneur, one of the best known bloggers in Germany
* Philipp Kandal, co-Founder and CTO of Skobbler (recently aquired for $24M by Telenav)

Many Thanks.

== License ==
Squirrly is Free to use. The version from the WP directory will install the Free Version.

You'll be able to use this seo software once you install the plugin and use your email to connect to Squirrly.co

For higher content marketing and SEO needs, you can check our Official Site and see what the PRO Plan offers.

== Frequently Asked Questions ==
= I can't log into the Wordpress with my user. Get the message 'An error occured.' What can I do? =
I see that your host server is not letting you to access our remote API.
Please tell your web master to add the IPs 144.76.66.106 and 176.9.112.210 in the white-list for remote access and it should work.

= How does Squirrly WordPress SEO Plugin work? =
Neil Patel, the Co-Founder of Kissmetrics and Crazy Egg made a great video on how to use Squirrly's Live Assistant:
http://www.quicksprout.com/university/how-to-maximize-your-seo-traffic-with-these-must-have-wordpress-plugins/

= How does the META Description work in Squirrly SEO Optimization? =
Based on your article, Squirrly will find the most relevant text and add it in the META Description.

You can opt-in to use the Squirrly Snippet in the Post/Page editor, which will allow you to customize how the META Title and Description will be. All while writing or editing your article.

= 100% green in Squirrly Live Assistant but I’m not getting traffic yet =
Sometimes we receive emails with this question and I want to help everybody have the correct image of Squirrly Live Assistance.
http://howto.squirrly.co/wordpress-seo/100-green-in-squirrly-live-assistant-but-im-not-getting-traffic/

= Is Squirrly SEO Plugin free? =
Yes, you just have to install the plugin from the WP directory into your site. Then connect with your email to Squirrly. The Free Version will automatically start. Read below for more. Once you have bigger content marketing needs, you can opt-in to upgrade to the PRO Plan.

= Does the Free Plan offer all the features? =
As of January 2015 the free plan will include the Lite version of our features. The paid version will open the PRO features. The free version has all a small Wordpress site or blog needs to get started with SEO and Content Marketing. These are the blogs on which owners want to publish about 5 articles / month. Also includes a general Audit of their whole site and want to see the SEO analytics for their last posts.

= What about the PRO Plan? =
The PRO Plan is for those with bigger content marketing and SEO needs. For anything regarding the paid plans, go to our website: http://howto.squirrly.co/squirrly-pricing-plans/

The Wordpress directory listing is only to be used for concerns regarding the Free version. You can get the PRO Plan after you've installed the plugin from this directory.

= Can I use squirrly seo on mobile? =
Yes, on IOS and ANDROID, it works both through the browser and Wordpress app

= Can I use the images, tweets and articles given by the Inspiration Box? Are there any legal concerns? =
Yes, you can use the tweets and the paragraphs in your articles. They contain a link to the source and are perfectly legal to use. Of course, for the
articles add only some paragraphs, not the whole article. As for the images, you can use the Copyright-Free images that we offer, to make sure you will
not have any legal problems. Follow the license-compliance guidance we offer for each of them.

= Do I get support for your WordPress SEO Plugin? =
Yes, we are focused on Delivering Happiness and this comes along with a good support package. We have a track record of replying in under 5 hours to
any request, no matter the time of day. And we also fix any problems which you may encounter very fast, so Squirrly is trust-worthy.

= What Features does Squirrly SEO Plugin offer? =
All of the features that we offer have been built having the customer's best interests in mind. We brought 90% of our clients to the first page of Google
and we've proven time and again that we are a great team that knows all there is to know about good *SEO automation*. We had a community of 20,000 blogs that all
used our SEO techniques, and they have gotten lots of hits from search engines due to our optimization. Now we offer the same quality for you:

 [UPDATE] Squirrly now has over 1,500,000 downloads, so we've been offering great software for over two years now.

- SEO Advice as you're typing your articles
- Advice in real time from the SEO Live Assistant on how to write better content for your Human readers
- Weekly SEO Audit report, that shows you how well you did on: Blogging, Traffic, Links, SEO, Social Media and Authority
- Lots of advice in the reports for how you can fix each section
- Keyword Research and Analysis (that takes data from both SEMrush AND Social Media)
- Monitors your Site's Progress
- SEO Analytics for each post or page
- Shows you rank in Google
- Shows you Social Signals for each article
- Social Intelligence
- Images you can use (with advice on License for each image. Most are Free to use)
- Read Tweets, Wikis, Blogs
- Insert Tweets, Wikis, Blogs
- Headline Suggestions for your SEO Keyword or general topic
- You'll be alerted if there are SEO issues, 404 errors, visibility problems
- Search of images, tweets, wikis, blogs, etc. based on your keyword
- As you type your article or edit older articles, you can set the META information for that article (using the Squirrly Snippet)
- Facebook Open Graph support for both Images and Videos (if you have a video in your article, Squirrly will attach the open graph properties to it)
- Twitter Cards
- Customize your FavIcon
- Adds the icon for Apple Devices
- Google Analytics setup support
- Google Webmaster Tools setup support
- Google Json-LD Structured data
- Google+ URL
- Bing META Code support
- Facebook META Code support
- adds the correct seo title in the home page
- adds the correct seo description and seo keywords in all pages
- adds canonical link in all pages
- adds the XML Sitemap for search engines: /sitemap.xml
- PING the XML Sitemap in google and bing
- adds the required METAs for home page (icon, author, language, dc publisher, hreflang, etc.)
- adds the favicon and the icon for Apple devices.
- Support for Custom Post Types
- Fine tune Page Navigational Links
- Provides SEO Integration for WP e-Commerce sites
- Support for CMS-style WordPress installations
- optimizes your titles for search engines
- Generates META tags automatically
- For beginners, all these settings are made automatically to get the best SEO possible.
- For advanced users, you can fine-tune everything.
- You can override any title and set any META description and any META keywords you want.
- Real Time Snippet Preview (checks the frontend of each article, not just a preview)
- Integrated with other Ecommerce Plugins like WooCommerce, WP Ecommerce, MarketPress, Ready!, Shopp
- Compatibility with all the other plugins, like Auto Meta, Ultimate Tag Warrior and others.
- Works best with multisites
- SEO error check and fix the META duplicates  

And the best ones that we have (and the others don't):
 - *Keyword research and SEO Analysis*: find the keywords that are easier to rank for
 - *SEO Live Assistant*: Your WordPress gives you SEO advice as you type or Edit your article
 - *Inspiration box*: get images you can use for free, tweets you can quote and get up to date with latest news about your subject 
 - *SEO Rank*: Measure and Monitor the impact of SEO and Social Signals for each of your articles

= Where can I enter the title and page description? = 
If you click the Squirrly tab in your dashboard, go to the "First Page Optimization" section and switch the Title and Description option on. You can enter custom Title, Description and Keywords. 

= Is this Wordpress SEO plugin the only SEO plugin I will need to install? =
It all depends on how you have setup your Wordpress until now. Some people use Squirrly seo plugin only for the Content Optimization with the Live Assistant part, some use use it to check their SEO stats and see where they need to improve their Wordpress seo, but most of our users and customer use Squirrly for everything related to SEO: from keyword analysis, to seo settings on Wordpress, to analytics and to weekly monitoring and audit reports.        
                      