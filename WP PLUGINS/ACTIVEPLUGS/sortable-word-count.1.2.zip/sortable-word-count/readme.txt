=== Sortable Word Count ===
Contributors: janisi
Tags: admin, column, word count, posts, pages, sortable, count, words
Requires at least: 4.0
Tested up to: 4.5.2
Stable tag: 1.2
Donate link: No donations.
License: GPL2
License URI: http://www.gnu.org/licenses/old-licenses/gpl-2.0.html

Sortable word count for posts or pages. Plugin adds a sortable column to the admin's post manager, displaying the word count for each post.

== Description ==
Sortable word count adds a sortable column to the admin's post manager, displaying the word count for each post.

== Installation ==
Upload plugin to your plugins folder (unzip) and activate it in WP admin.

== Frequently Asked Questions ==
No questions yet.

== Screenshots ==
1. [WordPress Plugin](https://wordpress.org/plugins/sortable-word-count) - Posts
2. [WordPress Plugin](https://wordpress.org/plugins/sortable-word-count) - Pages

== Changelog ==
1.2.

Readme.txt file fix. Setting correct plugin name.

1.1.

Core: Added prefix for all function names in plugin.

Core: Fixed problem with public page not to run.

1.0

Initial code.

== Upgrade Notice ==
No action required.