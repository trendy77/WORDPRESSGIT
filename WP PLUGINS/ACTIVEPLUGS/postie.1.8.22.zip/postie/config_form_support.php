<div id="simpleTabs-content-7" class="simpleTabs-content">
    <div style="">
        <h3>Postie Support</h3>
        <p>Please use the Postie <a href="https://wordpress.org/support/plugin/postie" target="_blank">support forums</a></p>
        <h3>More Postie info</h3>
        <p>Visit <a href="http://postieplugin.com/" target="_blank">PostiePlugin.com</a> for lots of information and assistance 
            including information for developers wanting to leverage/extend Postie.</p>
    </div>
    <div>
        <h3>Postie AddOns</h3>
        <p>There are a number of different AddOns available to extend Postie's functionality.
            See <a href='http://postieplugin.com/add-ons/' target='_blank'>the list</a> for more information.</p>
        <div>
            <div id='postie-addons'></div>
        </div>
    </div>
</div>