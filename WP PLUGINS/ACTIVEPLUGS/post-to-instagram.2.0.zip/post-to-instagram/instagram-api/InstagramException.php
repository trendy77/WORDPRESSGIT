<?php

class InstagramException extends \Exception
{
}
