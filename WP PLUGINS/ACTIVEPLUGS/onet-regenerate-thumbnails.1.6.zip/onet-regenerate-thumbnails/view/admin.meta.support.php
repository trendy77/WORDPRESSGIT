<div id="<?php echo $id; ?>" class="postbox orte-box">
	<div class="handlediv" title=""><br /></div>
	<h3 class="hndle"><span><?php echo $title; ?></span></h3>
	<div class="inside">
		<?php echo $content; ?>
	</div>
</div>