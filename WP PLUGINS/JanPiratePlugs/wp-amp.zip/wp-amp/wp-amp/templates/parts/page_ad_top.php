<?php if ( $this->options->get( 'page_ad_top' ) ) {
	echo $this->render( 'ad-top' );
}