<?php
/**
 * @var $this AMPHTML_Template
 */

if ( $this->options->get( 'archive_ad_bottom' ) ) {
	echo $this->render( 'ad-top' );
}