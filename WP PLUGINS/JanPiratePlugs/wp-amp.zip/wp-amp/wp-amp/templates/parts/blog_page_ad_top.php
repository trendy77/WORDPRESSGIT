<?php if ( $this->options->get( 'blog_page_ad_top' ) ) {
	echo $this->render( 'ad-top' );
}
