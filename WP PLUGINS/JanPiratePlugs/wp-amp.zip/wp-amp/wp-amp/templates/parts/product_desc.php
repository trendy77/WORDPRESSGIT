<?php if( $this->options->get( 'product_desc' ) ): ?>
	<div class="ampcontent">
		<?php echo $this->content; ?>
	</div>
<?php endif; ?>
