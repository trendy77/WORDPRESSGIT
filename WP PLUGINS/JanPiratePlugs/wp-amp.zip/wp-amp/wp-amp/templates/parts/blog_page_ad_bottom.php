<?php if ( $this->options->get( 'blog_page_ad_bottom' ) ) {
	echo $this->render( 'ad-bottom' );
}