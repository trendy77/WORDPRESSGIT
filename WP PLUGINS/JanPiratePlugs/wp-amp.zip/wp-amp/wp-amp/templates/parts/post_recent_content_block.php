<?php
if ( $this->options->get( 'post_recent' ) ) {
	echo $this->render( 'recent-posts' );
}