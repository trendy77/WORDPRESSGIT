<?php if ( $this->options->get( 'page_social_share' ) ) {
	echo $this->render( 'social-share' );
}