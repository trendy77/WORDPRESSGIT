<?php if ( $this->is_featured_image() ): ?>
	<?php echo $this->render_element( 'image', $this->featured_image ) ?>
<?php endif;
