<?php
if ( $this->options->get( 'search_page_ad_top' ) ) {
	echo $this->render( 'ad-top' );
}
