<?php
echo $this->content;