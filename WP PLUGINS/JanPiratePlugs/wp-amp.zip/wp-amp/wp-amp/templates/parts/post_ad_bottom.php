<?php if ( $this->options->get( 'post_ad_bottom' ) ) {
	echo $this->render( 'ad-bottom' );
}