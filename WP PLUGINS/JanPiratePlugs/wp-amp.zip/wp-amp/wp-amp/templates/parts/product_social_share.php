<?php if ( $this->options->get( 'product_social_share' ) ) {
	echo $this->render( 'social-share' );
}