<?php if ( $this->options->get( 'search_form' ) ): ?>
	<p><?php echo $this->render( 'searchform' ); ?></p>
<?php endif; ?>
