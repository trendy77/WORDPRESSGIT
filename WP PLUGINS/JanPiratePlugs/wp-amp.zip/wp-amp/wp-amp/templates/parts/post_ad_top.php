<?php if ( $this->options->get( 'post_ad_top' ) ) {
	echo $this->render( 'ad-top' );
}