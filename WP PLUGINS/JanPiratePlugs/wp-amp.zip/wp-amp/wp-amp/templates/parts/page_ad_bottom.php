<?php if ( $this->options->get( 'page_ad_bottom' ) ) {
	echo $this->render( 'ad-bottom' );
}