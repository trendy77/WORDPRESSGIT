<?php if ( $this->options->get( 'post_social_share' ) ) {
	echo $this->render( 'social-share' );
}