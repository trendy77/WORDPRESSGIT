<?php
$content = $this->content->save();
echo $this->content;