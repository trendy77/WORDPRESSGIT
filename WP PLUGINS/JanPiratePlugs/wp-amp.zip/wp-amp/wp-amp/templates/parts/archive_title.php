<?php
the_archive_title( '<h1 class="amphtml-title">', '</h1>' );