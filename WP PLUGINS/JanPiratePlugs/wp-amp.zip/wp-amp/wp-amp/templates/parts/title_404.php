<h2 class="amphtml-title">
	<?php printf( __( '%s', 'amphtml' ),  $this->options->get( 'title_404' ) ) ; ?>
</h2>
