<div id="pagination">
	<div class="next"><?php next_posts_link( __( 'Next &raquo;', 'amphtml' ), 0 ) ?></div>
	<div class="prev"><?php previous_posts_link( __( '&laquo; Previous', 'amphtml' ) ); ?></div>
	<div class="clearfix"></div>
</div>
