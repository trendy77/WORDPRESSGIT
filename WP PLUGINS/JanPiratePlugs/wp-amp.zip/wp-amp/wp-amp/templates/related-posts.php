<?php
/**
 * @var $this AMPHTML_Template
 */
?>
<?php
$count = $this->get_posts_count( 'related' );
$related = $this->get_related_posts( $this->post, $count );
?>
<?php if ( $related && $related->have_posts()) : ?>
	<aside>
		<h3><?php echo $this->get_posts_title( 'related' ); ?></h3>
		<ul class="wp-amp-recent-posts-list">
			<?php $show_thumbnail = $this->get_posts_thumbnail( 'related' ); ?>
			<?php while ( $related->have_posts() ) : $related->the_post(); ?>
				<?php $link = get_permalink( get_the_id() ); ?>
				<li>
					<a href="<?php echo $this->get_amphtml_link( $link ); ?>" title="<?php the_title_attribute(); ?>">
						<?php if( $show_thumbnail ) :
							$this->the_post_thumbnail_tpl( get_the_ID() );
						endif; ?>
						<?php the_title(); ?>
					</a>
				</li>
			<?php endwhile; ?>
		</ul>
	</aside>
<?php endif;