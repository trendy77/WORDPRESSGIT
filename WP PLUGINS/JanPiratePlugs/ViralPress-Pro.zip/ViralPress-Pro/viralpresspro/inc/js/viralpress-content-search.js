var toType = function(obj) {
  return ({}).toString.call(obj).match(/\s([a-zA-Z]+)/)[1].toLowerCase()
}

/** Init **/
var Search = function() {
    this.config = app_config;
    this.ui = new Ui();
    this.app = new App();
    //init
    this.init();
    this.posts = [];
    this.posts_limit = 10;
    this.posts_per_page = 10;
};

Search.prototype.init = function() {
    this.initForms();
};

/** Show Pages **/
Search.prototype.showPages = function(url) { 
    var $this = this;
    ShowLoader('show');
    FB.api(url, function(response) {
        jQuery($this.ui.elements.search_form).find('button[type=submit]').attr('disabled', false);
        jQuery("body").css("cursor", "default");
        if (response.error === undefined) {
            $this.ui.showValidationErrors({});
            if(response.data != 0) {
                var pages = response.data;
                var results = jQuery($this.ui.elements.results_table).find('tbody');
                results.html('');
                for (i in pages) {
                    FB.api('/' + pages[i].id + '/?fields=likes,picture,about,name', function(response) {
                        jQuery("body").css("cursor", "default");
                        if (response && !response.error) {
                            if (response.about) {
                                var likesData = ''; var totalLike = 0;
                                //console.log(response.likes);
                                if(response.hasOwnProperty('likes')) {
                                    if(response.likes.hasOwnProperty('data')) {
                                        var likesData = '<div class="likes-info-hover">';
                                        jQuery.each(response.likes.data, function(key, likeValue){
                                            if(key>5) { var otherLike = (response.likes.data.length-key); likesData += '<p>and '+otherLike+' more...</p>';return false; }
                                            likesData += '<p>'+likeValue.name+"</p>";
                                        });
                                        likesData += '</div>';
                                        totalLike = response.likes.data.length;
                                    }
                                    if(totalLike==0) {
                                        totalLike = response.likes;
                                    }
                                }
                                results.append('<tr> \
                                    <td> \
                                        <img src="' + response.picture.data.url + '" alt="" style="width:auto;height:auto;max-width:180px;" /> \
                                    </td> \
                                    <td> \
                                        <h4>' + response.name + '</h4> \
                                        <p>' + response.about + '</p> \
                                        <div class="likes-info">\
                                            <a href="#" class="label label-info">' + totalLike + '</a> Likes \
                                            '+likesData+'\
                                        </div>\
                                    </td> \
                                    <td style="width:100px;"> \
                                        <a href="#" class="btn btn-success show_recent_posts" data-id="' + response.id + '"><span class="dashicons dashicons-list-view"></span> Explore</a> \
                                    </td> \
                                </tr>');
                            }
                            $this.initRecentPosts(); $this.initFilters();
                        }
                    });
                }
                // Pagination           $this.initFilters();
                if (response.paging != undefined) {
                    if (response.paging.next != undefined) {
                        jQuery('a#pages_pagination_next').attr('href', response.paging.next).css('display', 'block');
                    } else {
                        jQuery('a#pages_pagination_next').attr('href', '#').css('display', 'none');
                    }
                    if (response.paging.previous != undefined) {
                        jQuery('a#pages_pagination_previous').attr('href', response.paging.previous).css('display', 'block');
                    } else {
                        jQuery('a#pages_pagination_previous').attr('href', '#').css('display', 'none');
                    }
                }
            } else {
                jQuery($this.ui.elements.results_table+' tbody').html('<tr><td class="blankdatas" colspan="3"><span>'+viralpress_pro_search.no_page+'</span></td></tr>');
                jQuery('a#pages_pagination_next').attr('href', '#').css('display', 'none');
                jQuery('a#pages_pagination_previous').attr('href', '#').css('display', 'none');
            }
            jQuery($this.ui.elements.posts_table).hide();
            jQuery($this.ui.elements.results_table).show();
        } else {
            var errors = {};
            errors.search_term = response.error.message.toString();
            $this.ui.showValidationErrors(errors);
        }
        ShowLoader('hide');
    });
};

/** Init Forms **/
Search.prototype.initForms = function() {
    var $this = this;
    jQuery($this.ui.elements.search_form).unbind('submit').on('submit', function(e) { 
        e.preventDefault();
        jQuery($this.ui.elements.search_form).find('button[type=submit]').attr('disabled', true);
        jQuery("body").css("cursor", "progress");
        jQuery('#records_number').html('');
        var search_term = jQuery(this).find('input[name=search_term]').val().toString();
        $this.showPages('/search?q=' + search_term + '&type=page');
    });
    jQuery('a.search_paging').unbind('click').on('click', function(e) {
        e.preventDefault();
        var url = jQuery(this).attr('href');
        $this.showPages(url);
    });
};
Search.prototype.showPosts = function(posts) {
    var $this = this;
    posts.sort(function(a, b){
        var a_l, b_l;
        a_l = a.likes != undefined ? a.likes.summary.total_count : 0;
        b_l = b.likes != undefined ? b.likes.summary.total_count : 0;
        return b_l-a_l;
    });
    var results_video = jQuery($this.ui.elements.recent_videoresults_table).find('tbody');
    var results_images = jQuery($this.ui.elements.recent_imageresults_table).find('tbody');
    results_video.html('');
    results_images.html('');
    var image_num = 0;
    var video_num = 0;
    
    for (i in posts) {
        var shares = posts[i].shares != undefined ? '<span class="label label-primary">' + posts[i].shares.count + '</span> Shares' : '';
        var picture = posts[i].picture != undefined ? '<img src="' + posts[i].picture + '" alt="" style="width:auto;height:auto++;max-width:180px;">' : '';
        var date = new Date(posts[i].created_time);
        var created_time = date.getTime();
        var hrdate = date.toDateString();
        var jQueryresults;
        var type = 'image';

        if (posts[i].attachments != undefined) {
           if (posts[i].attachments.data[0].type !== "photo" && (posts[i].source)) {
                jQueryresults = results_video;
                var download = '<a class="btn btn-default" href="' + posts[i].source + '" target="_blank" download="' + posts[i].source + '"  title="Download"><span class="dashicons dashicons-download"></span></a>';
                var save = '<a class="btn btn-default viralpressSaveMedia" data-url="' + posts[i].source + '" download="' + posts[i].source + '" title="Save in Media"><span class="dashicons dashicons-admin-post"></span></a>';
                type = 'video';
            } else {
                jQueryresults = results_images;
                if ((posts[i].attachments.data) && (posts[i].attachments.data[0].media)) {
                    var download = '<a  class="btn btn-default" href="' + posts[i].attachments.data[0].media.image.src + '" target="_blank" download="' + posts[i].attachments.data[0].media.image.src + '" title="Download"><span class="dashicons dashicons-download"></span></a>';
                    var save = '<a class="btn btn-default viralpressSaveMedia" data-url="' + posts[i].attachments.data[0].media.image.src + '" download="' + posts[i].attachments.data[0].media.image.src + '" title="Save in Media"><span class="dashicons dashicons-admin-post"></span></a>';
                } else {               
                    var download = '';
                    var save = '';
                }
            }
            var likes = posts[i].likes != undefined ? posts[i].likes.summary.total_count : '0';
            //console.log(likes); asdad
            var message = posts[i].message != undefined ? posts[i].message : '';  
            var el_id = ''
            if (type == 'image') { el_id = 'el_' + type + '_' + image_num; image_num++; } 
            else { el_id = 'el_' + type + '_' + video_num; video_num++; }
            jQuery("#results").hide(); jQuery("#posts").show();
            jQueryresults.append('<tr data-likes="' + likes + '" data-created-time="' + created_time + '" id="' + el_id +'" class="el_'+ type +'"> \
                <td class="col-md-1"> \
                    ' + picture + ' \
                </td> \
                <td class="col-md-8"> \
                    <p>' + message + '</p> \
                    <div style="font-size: 12px;"> \
                        <span class="label label-info">' + likes + '</span> Likes \
                        ' + shares + ' | \
                        <strong>Created</strong>: ' + hrdate + ' \
                        ' +  ' \
                    </div> \
                </td> \
                <td class="col-md-3"> \
                    <a target="_blank" href="https://www.facebook.com/' + posts[i].id + '" class="btn btn-default" title="View On Facebook"><span class="dashicons dashicons-visibility"></span> </a> \
                    <a href="#" class="fb_share btn btn-primary" onclick="gotoTop()" data-link="' + posts[i].link + '"><span class="dashicons dashicons-megaphone"></span> Viral</a> \
                    ' + download + ' \
                    ' + save + ' \
                </td> \
            </tr>');
            $this.initFBShare();
        }
    }
    jQuery('#page-video').bootpag({
            total: Math.ceil(video_num/$this.posts_limit),
            maxVisible: 7
    }).on("page", function(event, num){
             $this.displayPage(num, 'video');
     });
    jQuery('#page-image').bootpag({
            total: Math.ceil(image_num/$this.posts_limit),
            maxVisible: 7
    }).on("page", function(event, num){
             $this.displayPage(num, 'image');
    });    
    jQuery('#posts_video, #posts_images').find('tbody > tr').attr('data-hidden', 'false');
    var videosdatastrue = results_video.html();
    var imagesdatastrue = results_images.html();
    if(videosdatastrue==='' || videosdatastrue==='undefined') {
        jQuery("#posts_video tbody").html('<tr><td class="blankdatas" colspan="3"><span>'+viralpress_pro_search.no_videos+'</span></td></tr>');
    }
    if(imagesdatastrue ==='' || imagesdatastrue==='undefined') {
        jQuery("#posts_images tbody").html('<tr><td class="blankdatas" colspan="3"><span>'+viralpress_pro_search.no_images+'</span></td></tr>');
    }
    $this.displayPage(1, 'image');
    $this.displayPage(1, 'video');
    jQuery($this.ui.elements.results_table).hide();
    jQuery($this.ui.elements.posts_table).show();

    /*** Media Save **/
    jQuery("a.viralpressSaveMedia").click(function(e){
        e.preventDefault(); ShowLoader('show');
        var medialUrl = jQuery(this).data('url');
        if ( medialUrl !== '' ) {
            var data = {'action':'viralpressSaveMedia', 'url' : medialUrl};
            jQuery.post(ajaxurl, data, function(response){
                ShowLoader('hide');
                var responseData = JSON.parse(response); console.log(responseData);
                if(responseData.success) {
                    
                }
            });
        }
    });
};

Search.prototype.displayPage = function(num, type){
     var $this = this;
     var start_element = ((num-1) * $this.posts_limit)

     jQuery('.el_'+ type).hide();

     if (start_element ==0) {
         jQuery('.el_'+ type +'[data-hidden="false"]:lt( ' + $this.posts_limit +')').show();
     } else {
         jQuery('.el_'+ type +'[data-hidden="false"]:gt(' + (start_element-1) + '):lt( ' + $this.posts_limit +')').show();
     }
}

Search.prototype.getPosts = function(url){
    var $this = this;
    ShowLoader('show');
    FB.api(url, function(response) {
        if (response && !response.error) {
            var p = response.data;
            for(i in p){
                $this.posts.push(p[i]);
                jQuery('#records_number').html($this.posts.length);
            }
            if(response.paging === undefined) {
                jQuery("body").css("cursor", "default");
                jQuery('.show_recent_posts').attr('disabled', false);
                ShowLoader('hide');
                $this.showPosts($this.posts);
            } else {
                if(response.paging.next != undefined && $this.posts.length < $this.posts_limit){
                    $this.getPosts(response.paging.next);
                } else {
                    jQuery("body").css("cursor", "default");
                    jQuery('.show_recent_posts').attr('disabled', false);
                    ShowLoader('hide');
                    $this.showPosts($this.posts);
                }
            }
        } else {
            if(response.error) {
                alert("Please Try Again...");
                jQuery('.show_recent_posts').attr('disabled', false);
                ShowLoader('hide');
            }
        }
    });
    jQuery("#close_process").click(function (e) {
        e.preventDefault(); $this.posts = [];
        jQuery('.show_recent_posts').attr('disabled', false);
        jQuery($this.ui.elements.posts_table).hide();
        jQuery($this.ui.elements.results_table).show();
    });
};
Search.prototype.initRecentPosts = function() {
   var $this = this;
    while ($this.posts.length > 0) {
        $this.posts.pop();
    }
    jQuery('.show_recent_posts').unbind('click').on('click', function(e) {
        jQuery('.show_recent_posts').attr('disabled', true);
        e.preventDefault();
        jQuery("body").css("cursor", "progress");
        var page_id = jQuery(this).attr('data-id');
        $this.getPosts('/' + page_id + '/feed?limit=100&fields=link,message,shares,picture,created_time,source,attachments{type,url,media},likes.summary(true)');
    });
    jQuery('#back').unbind('click').on('click', function(e) {
        e.preventDefault();
        $this.posts = [];
        jQuery($this.ui.elements.posts_table).hide();
        jQuery($this.ui.elements.results_table).show();
    });
}
Search.prototype.initFBShare = function() {
    $this = this;
    jQuery($this.ui.elements.fb_share_btn).unbind('click').on('click', function(e) {
        e.preventDefault();
        var link = jQuery(this).attr('data-link');
        FB.ui({
            method: 'share',
            href: link,
        }, function(response) { });
    });
};
Search.prototype.initFilters = function() {
    $this = this;
    jQuery($this.ui.elements.filters_form).unbind('submit').on('submit', function(e) {
        if (jQuery('#posted_x_days_ago').val() === '') {
            jQuery('#posted_x_days_ago').val(365);
        }
        if (jQuery('#min_likes').val() === '') {
            jQuery('#min_likes').val(0);
        }
        e.preventDefault();
        var dateOffset = (24 * 60 * 60 * 1000) * jQuery('#posted_x_days_ago').val();
        var myDate = new Date();
        myDate.setTime(myDate.getTime() - dateOffset);
        var x_timestamp = myDate.getTime();
        var min_likes = parseInt(jQuery('#min_likes').val());
        jQuery('.el_image').each(function(e) {
            jQuery(this).attr('data-hidden', 'true');
            var created_time = parseInt(jQuery(this).attr('data-created-time'));
            var likes = parseInt(jQuery(this).attr('data-likes'));
            if ((created_time >= x_timestamp) && (likes >= min_likes)) {
                jQuery(this).attr('data-hidden', 'false');
            }
        });
        jQuery('.el_video').each(function(e) {
            jQuery(this).attr('data-hidden', 'true');
            var created_time = parseInt(jQuery(this).attr('data-created-time'));
            var likes = parseInt(jQuery(this).attr('data-likes'));
            if ((created_time >= x_timestamp) && (likes >= min_likes)) {
                jQuery(this).attr('data-hidden', 'false');
            }
        });
         jQuery('#page-image').bootpag({total:Math.ceil(jQuery('.el_image[data-hidden="false"]').length/$this.posts_limit), maxVisible: 7, page: 1});
         jQuery('#page-video').bootpag({total:Math.ceil(jQuery('.el_video[data-hidden="false"]').length/$this.posts_limit), maxVisible: 7, page: 1});
         $this.displayPage(1, 'image');
         $this.displayPage(1, 'video');

    });
    /* For the Sort Search Data */
    jQuery($this.ui.elements.viral_sorting).unbind('change').on('change', function(e) {
        var sorting_id = jQuery(this).val();
        if(sorting_id == "1") { 
            sortTable(jQuery($this.ui.elements.results_table), 'asc', 'h4');
        } else if (sorting_id == "2") {
            sortTable(jQuery($this.ui.elements.results_table), 'asc', 'span');
        }
    });
    /* For the Recent Post Sorting */
    jQuery($this.ui.elements.viral_recentpost_sorting).unbind('change').on('change', function(e) {
        if(jQuery($this.ui.elements.recent_post_tabs).find('li.active a').attr('aria-controls')==='video') {
            $dataresults = jQuery($this.ui.elements.recent_videoresults_table);
        } else {
            $dataresults = jQuery($this.ui.elements.recent_imageresults_table);
        }
        var sorting_id = jQuery(this).val();
        if(sorting_id == "1") { 
            sortTable($dataresults, 'asc', 'div span:first');
        } else if (sorting_id == "2") {
            sortTable($dataresults, 'asc', 'div span:last');
        }
    });
};

/** Function For the Sort Data */
function sortTable(table, order, sort_id) { 
    var asc   = order === 'asc', tbody = table.find('tbody'); 
    tbody.find('tr').sort(function(a, b) {
        var firstval = '', secondval = '';
        if(jQuery.isNumeric(jQuery('td '+sort_id, b).text()) || jQuery.isNumeric(jQuery('td '+sort_id, a).text())) {
            secondval = parseInt(jQuery('td '+sort_id, a).text());
            firstval = parseInt(jQuery('td '+sort_id, b).text());
        } else {
            firstval = jQuery('td '+sort_id, a).text().toString().toUpperCase();
            secondval = jQuery('td '+sort_id, b).text().toString().toUpperCase();        
        }
        if (asc) {
            return firstval > secondval ? 1 : -1;
        } else {
            return firstval > secondval ? -1 : 1;
        }
    }).appendTo(tbody);
}

// Go To Top
function gotoTop() {
    jQuery('body,html').animate({ scrollTop: 0 }, 800); 
    return false;
}

function ShowLoader(action, type) {
    if(action=='show') {
        jQuery('#pleaseWaitDialog').modal('show');
    } else if(action=='hide') {
        jQuery('#pleaseWaitDialog').modal('hide');
    }
}