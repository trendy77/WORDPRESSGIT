<?php
/**
*	Plugin Name: ViralPress Pro
*	Plugin URI: https://indigothemes.com/products/viralpress-pro-viral-content-finder-wordpress-plugin/
*	Description: ViralPress Pro is the most powerful and unique WordPress plugin to find and analyze viral content from Facebook for any business/niche.
*	Version: 1.1
*	Author: IndigoThemes
*	Author URI: https://indigothemes.com/
*	Text Domain: viralpress-pro
*	Domain Path: /languages
*	License: GPLv3 or later
*	License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

Class ViralPress_Pro {

	// Register INIT viralpress-pro
	public function __construct() {
		add_action( 'admin_menu', array(&$this, 'viralpress_pro_menu') );
		add_action( 'admin_enqueue_scripts', array(&$this, 'viralpress_assets') );
		add_action( 'init', array(&$this, 'viralpress_text_domain') );
		add_action( 'admin_init', array(&$this, 'viralpress_pro_settings_update' ), 0 );
	}

	// Text Domain
	public function viralpress_text_domain() {
		load_plugin_textdomain( 'viralpress-pro', false, basename( dirname( __FILE__ ) ) . '/languages' );
	}

	// Init & Call Js Files In Header.
	public function viralpress_assets() {
		wp_enqueue_style( 'viralpress-pro-menuicno-css', plugins_url('inc/css/viralpress-pro-menuicno.css', __FILE__),array());
		wp_register_style( 'bootstrap-min-css', plugins_url('inc/css/bootstrap.min.css', __FILE__),array(), '3.2.0' );
		wp_register_script( 'bootpage-min-js', plugins_url('inc/js/jquery.bootpag.min.js', __FILE__),array(), '1.0.7' );
		wp_register_script( 'bootstrap-min-js', plugins_url('inc/js/bootstrap.min.js', __FILE__),array(), '3.1.1' );
		wp_register_style( 'viralpress-pro-css', plugins_url('inc/css/viralpress-pro.css', __FILE__), array() );
		wp_register_script( 'viralpress-search-script', plugins_url('inc/js/viralpress-content-search.js', __FILE__),array() );
		wp_register_script( 'viralpress-search-all', plugins_url('inc/js/viralpress-pro.js', __FILE__),array() );
	}

	// viralpress-pro Menus.
	public function viralpress_pro_menu() {
		$viralPressPage = add_menu_page( 'ViralPress Pro', 'ViralPress Pro', 'manage_options', 'viralpress-pro', array(&$this,'viralpress_pro_options'), '' );
		add_action("admin_print_styles-{$viralPressPage}", array(&$this, 'ViralPressAssetsEnqueues'));
		$viralPressPage = add_submenu_page( 'viralpress-pro', 'ViralPress Settings', 'ViralPress Settings', 'manage_options', 'viralpress-pro' );
		add_action("admin_print_styles-{$viralPressPage}", array(&$this, 'ViralPressAssetsEnqueues'));
		$viralPressPage = add_submenu_page( 'viralpress-pro', 'Viral Content Finder', 'Viral Content Finder', 'manage_options', 'viralpress-content-finder', array(&$this, 'viralpress_pro_options_callback') );
		add_action("admin_print_styles-{$viralPressPage}", array(&$this, 'ViralPressAssetsEnqueues'));
		$viralPressPage = add_submenu_page( 'viralpress-pro', 'Documentation', 'Documentation', 'manage_options', 'viralpress-pro-support', array(&$this, 'viralpress_support' ) );
		add_action("admin_print_styles-{$viralPressPage}", array(&$this, 'ViralPressAssetsEnqueues'));
		$viralPressPage = add_submenu_page( 'viralpress-pro', 'FB Support Group', 'FB Support Group', 'manage_options', 'viralpress-pro-every-group-support', array(&$this, 'viralpress_fb_supportGroup' ) );
		add_action("admin_print_styles-{$viralPressPage}", array(&$this, 'ViralPressAssetsEnqueues'));
	}

	public function ViralPressAssetsEnqueues() {
		wp_enqueue_style( 'bootstrap-min-css');
		wp_enqueue_style( 'viralpress-pro-css');
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script('bootpage-min-js');
		wp_enqueue_script('bootstrap-min-js');
	}

	// viralpress-pro Options.
	public function viralpress_pro_options() {
		if ( !current_user_can( 'manage_options' ) )  {
			wp_die( _e('You do not have sufficient permissions to access this page.', 'viralpress-pro') );
		}
		echo '<div class="wrap">'; ?>
		<h2><?php _e('Facebook Settings', 'viralpress-pro'); ?></h2>
		  <form method="post" action="options.php" id="fb_settings">
		    <?php settings_fields( 'viralpress-settings' ); ?>
		    <?php do_settings_sections( 'viralpress-settings' ); ?>
		    <table class="form-table">
		      <tr valign="top">
		      	<th scope="row">
		      		<label for="app_id"><?php _e('Facebook Application ID', 'viralpress-pro'); ?>:</label>
		      	</th>
		      	<td>
		      		<input type="text" name="app_id" id="app_id" value="<?php echo get_option( 'app_id' ); ?>"/>
		      	</td>
		      </tr>
		    </table>
		    <?php submit_button(); ?>
		  </form>
		<?php echo "</div>"; 
	}

	// viralpress-pro CallBack Option.
	public function viralpress_pro_options_callback() {
		wp_enqueue_media();
		if ( !current_user_can( 'manage_options' ) )  {
			wp_die( _e('You do not have sufficient permissions to access this page.', 'viralpress-pro') );
		}
		include("viral-content-finder.php");
		wp_enqueue_script( 'viralpress-search-script');
		$viralpress_pro_translation = array('no_videos'=> __('It seems no videos were posted on this Facebook page.', 'viralpress-pro'), 'no_images'=> __('It seems no images were posted on this Facebook page.', 'viralpress-pro'), 'no_page'=> __('No Facebook page was found related to the keyword you entered.', 'viralpress-pro') );
		wp_localize_script( 'viralpress-search-script', 'viralpress_pro_search', $viralpress_pro_translation);
		wp_enqueue_script( 'viralpress-search-all');
		wp_localize_script( 'viralpress-search-all', 'viralpress_pro', array( 'welcome'=>__('Welcome', 'viralpress-pro'), 'success'=>__('You are successfully logged in from Facebook.', 'viralpress-pro'), 'login'=>__('Please login to Facebook by clicking','viralpress-pro'), 'here'=>__('here', 'viralpress-pro'), 'ajax_url'=>admin_url( 'admin-ajax.php' ) ) );
	}

	// Update viralpress-pro Settings.
	public function viralpress_pro_settings_update() {
		register_setting( 'viralpress-settings', 'app_id' );
		register_setting( 'viralpress-settings', 'viralpress_license_key' );
		register_setting( 'viralpress-settings', 'viralpress_license_key_status' );
	}
	
	// Get Facebook Details.
	public function viralpress_pro_getfacebookdetails() { 
		global $wpdb; 
		if(isset($_POST['get']) && ($_POST['get'])) {
			$data['app_id'] = get_option('app_id');
			echo json_encode($data);
		}
		exit;
	}

	// Support
	public function viralpress_support() {
		echo "<script>window.location.href = 'https://indigothemes.com/documentation/viralpresspro/';</script>";
	}

	// Every Group Support
	public function viralpress_fb_supportGroup() {
		echo "<script>window.location.href = 'https://www.facebook.com/groups/viralpresspro/';</script>";
	}

	/** Save Media From Url **/
	public function viralpressSaveMedia() {
		$retunrData = array();
		if(isset($_POST['url'])) {
			$fbMediaUrl = $_POST['url'];
			$fileName =pathinfo($fbMediaUrl, PATHINFO_FILENAME);
			$fileInfo = parse_url($fbMediaUrl);
			$fileExtension =pathinfo($fileInfo['path'], PATHINFO_EXTENSION);
			$newFileName = $fileName.'.'.$fileExtension;	
			$data = $this->ViralPressSaveRemoteFile($fbMediaUrl, $newFileName);
			if(!empty($data)) { $retunrData['success'] = true; }
			else { $retunrData['success'] = false; }
		}
		echo json_encode($retunrData); exit;
	}

	public function viralpressFetchDatas($url) {
		if ( function_exists("curl_init") ) {
		return viralpressFileGetContentsCurl($url);
		} elseif ( ini_get("allow_url_fopen") ) {
		return viralpressFOpenFetchImage($url);
		}
	}

	public function viralpressFOpenFetchImage($url) {
		$datas = file_get_contents($url, false, $context);
		return $datas;
	}

	public function viralpressFileGetContentsCurl($url) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER,1);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);       
		$data = curl_exec($ch);
		curl_close($ch);
		return $data;
	}

	/**
	*	Save image on wp_upload_dir.
	*	Add image to the media library and attach in the post.
	*
	*	@param string $url image url
	*	@param int $postID
	*	@return int $attch_id
	*/
	public function ViralPressSaveRemoteFile( $url, $filename = '', $options = array() ) {
		if ( !function_exists( 'curl_init' ) || empty( $filename ) ) {
			return;
		}
		$filename = sanitize_file_name( $filename );
		$uploadDir = wp_upload_dir();
		$filePath = urldecode( $uploadDir['path'] . '/' . $filename );
		$fileUrl = urldecode( $uploadDir['url'] . '/' . $filename );

		// Make sure we don't upload the same file more than once.
		if ( !file_exists( $filePath ) ) {
			$postID = 0;
			setlocale( LC_ALL, "en_US.UTF8" );
			$ch = curl_init( $url );
			if (isset($options['headers'])&&!empty( $options['headers'])) {
				curl_setopt( $ch, CURLOPT_HTTPHEADER, $options['headers'] );
			}
			curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
			curl_setopt( $ch, CURLOPT_SSL_VERIFYHOST, 2 );
			$fileContents = curl_exec( $ch );

			if ( $fileContents === false ) { return; }

			$fileType = curl_getinfo( $ch, CURLINFO_CONTENT_TYPE );
			$fileSize = curl_getinfo( $ch, CURLINFO_SIZE_DOWNLOAD );

			curl_close( $ch );
			file_put_contents( $filePath, $fileContents );

			$attachment = array(
				'guid' => $fileUrl,
				'post_mime_type' => $fileType,
				'post_title' => preg_replace( '/\.[^.]+$/', '', $filename ),
				'post_content' => '',
				'post_status' => 'inherit',
				'post_parent' => $postID,
			);
			$attachID = wp_insert_attachment( $attachment, $filePath, $postID );
			$attachData = wp_generate_attachment_metadata( $attachID, $filePath );
			wp_update_attachment_metadata( $attachID, $attachData );
			set_post_thumbnail( $postID, $attachID );
		} else {
			global $wpdb;
			$subdirFile = ltrim( $uploadDir['subdir'], '/' )  . '/' . $filename;
			$attachID = $wpdb->get_var( $wpdb->prepare( "SELECT pm.post_id FROM $wpdb->postmeta pm
			WHERE pm.meta_key = '_wp_attached_file' AND pm.meta_value = %s", $subdirFile ) );
		}
		return $attachID;
	}
}
// Install This Plugin using viralpress-pro Class.
$viralpress_pro = new ViralPress_Pro();

// viralpress-pro Get Facebook Details.
add_action( 'getviralpress_pro_facebookdetails', array( &$viralpress_pro, 'viralpress_pro_getfacebookdetails' ) );
add_action( 'wp_ajax_getviralpress_pro_facebookdetails', array( &$viralpress_pro, 'viralpress_pro_getfacebookdetails' ) );

add_action('wp_ajax_viralpressSaveMedia', array(&$viralpress_pro, 'viralpressSaveMedia'));
add_action('wp_ajax_nopriv_viralpressSaveMedia', array(&$viralpress_pro, 'viralpressSaveMedia'));