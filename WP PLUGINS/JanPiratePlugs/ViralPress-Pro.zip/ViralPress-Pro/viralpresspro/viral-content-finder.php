<?php defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); ?>

<!-- BEGIN LOGIN CONTENT -->
<div class="wrap">	
	<h2><?php _e('Viral Content Finder', 'viralpress-pro'); ?></h2>
	<div class="" id="login_status">
	</div>
	<div class="popup">
		<div class="modal fade in" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="loginModalLabel" data-keyboard="false" data-backdrop="static" aria-hidden="false" style="display: none;">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
						<h4 class="modal-title" id="loginModalLabel"><?php _e('Login', 'viralpress-pro'); ?></h4>
					</div>
					<div class="modal-body">
						<div class="main-login-form">
							<button id="fblogin" type="button" class="btn btn-primary"><span class="dashicons dashicons-facebook-alt"></span> | <?php _e('Connect with Facebook', 'viralpress-pro'); ?></button>
						</div>
					</div>
					<div class="modal-footer">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- END LOGIN CONTENT -->

<!-- BEGIN SEARCH CONTENT FOR THE SEARCHING PAGE IN FACEBOOK -->
<div class="col-md-12">
	<div class="row ad">
		<!-- BEGIN SEARCH FORM -->
		<form id="search_form">
			<div class="input-group">
				<!-- Seach Input Field With Button -->
				<input type="text" class="form-control" name="search_term" placeholder="<?php _e('Search for', 'viralpress-pro'); ?>...">
				<span class="input-group-btn">
					<button type="submit" class="btn btn-default"><span class="dashicons dashicons-search"></span></i><?php _e('Search', 'viralpress-pro'); ?></button>
				</span>
				</div>
		</form>
		<!-- END SEARCH FORM -->
		<!-- BEGIN SEARCH PAGE RESULTS LISTING -->		
		<div id="results">
			<table id="" class="table table-bordered table-striped" width="100%">
				<legend>
					<span><?php _e('Search results', 'viralpress-pro'); ?></span>
					<div class="select-style">
						<select name="viral_sort" id="viral_sort">
							<option value="">--<?php _e('Sort By', 'viralpress-pro'); ?>--</option>
							<option value="1"><?php _e('Title', 'viralpress-pro'); ?></option>
							<option value="2"><?php _e('Like', 'viralpress-pro'); ?></option>
						</select>
						<span class="dashicons dashicons-arrow-down"></span>
					</div>
				</legend>

				<thead>
					<tr>
						<th><?php _e('Image', 'viralpress-pro'); ?></th>
						<th><?php _e('Page Name', 'viralpress-pro'); ?></th>
						<th>&nbsp;</th>
					</tr>
				</thead>
				<tbody>
				</tbody>
			</table>
			<!-- BEGIN SEARCH PAGE RESULTS PAGINATION -->
			<div class="row page-nav">
				<div class="col-md-4 col-md-offset-4">
					<div class="btn-group" role="group" aria-label="...">
						<a data-type="search" id="pages_pagination_previous" href="" type="button" class="search_paging btn btn-default"><span class="dashicons dashicons-arrow-left-alt2"></span></a>
						<a data-type="search" id="pages_pagination_next" href="" type="button" class="search_paging btn btn-default"><span class="dashicons dashicons-arrow-right-alt2"></span></span></a>
					</div>
				</div>
			</div>
			<!-- END SEARCH PAGE RESULTS PAGINATION -->
		</div>
		<!-- END SEARCH PAGE RESULTS LISTING -->
		<!-- BEGIN PAGE IN POST RESULTS -->
		<div id="posts">
			<!-- Filters For The Post Listing Likes & Dates -->
			<div id="filters" class="row">
				<div class="col-md-12">
					<form id="filters_form" class="form-inline">
						<input type="hidden" name="page_id" value="">
						<div class="form-group">
							<label for="likes_count"><?php _e('Posted X days ago', 'viralpress-pro'); ?></label>
							<input type="text" class="form-control" id="posted_x_days_ago" value="365" placeholder="<?php _e('Likes', 'viralpress-pro'); ?>">
						</div>
						<div class="form-group">
							<label for="likes_count"><?php _e('Minimum likes', 'viralpress-pro'); ?></label>
							<input type="text" class="form-control" id="min_likes" value="0" placeholder="<?php _e('Likes', 'viralpress-pro'); ?>">
						</div>
						<button type="submit" class="btn btn-success"><span class="dashicons dashicons-filter"></span>  <?php _e('Filter', 'viralpress-pro'); ?></button>
					</form>
				</div>
			</div>
			<!-- Back to Page Listings -->
			<div class="row">
				<div class="col-md-4 col-md-offset-4">
					<button class="btn btn-default" id="back" style="margin: 0 auto; display:block;"><span class="dashicons dashicons-arrow-left-alt"></span> <?php _e('Back', 'viralpress-pro'); ?></button></div>
			</div>
			<!-- BEGIN RECENT POST OF FB PAGE -->
			<div class="row">
				<div class="col-lg-12">
					<legend class="recent_posts">
						<span><?php _e('Recent posts', 'viralpress-pro'); ?></span>
						<!-- SORTING BY LIKES & SHARES -->
						<div class="select-style">
							<select name="viral_recentpost_sorting" id="viral_recentpost_sorting">
								<option value="">--<?php _e('Sort By', 'viralpress-pro'); ?>--</option>
								<option value="1"><?php _e('Like', 'viralpress-pro'); ?></option>
								<option value="2"><?php _e('Share', 'viralpress-pro'); ?></option>
							</select>
                            <span class="dashicons dashicons-arrow-down"></span>
						</div>
					</legend>
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" id="recent_post_tabs" role="tablist">
						<li role="presentation" class="active"><a href="#video" aria-controls="video" role="tab" data-toggle="tab"><?php _e('Videos', 'viralpress-pro'); ?></a></li>
						<li role="presentation"><a href="#images" aria-controls="images" role="tab" data-toggle="tab"><?php _e('Images', 'viralpress-pro'); ?></a></li>
					</ul>
					<!-- BEGIN TAB PANEL -->
					<div class="tab-content">
						<!-- BEGIN VIDEOS POSTS -->
						<div role="tabpanel" class="tab-pane active" id="video">
							<table id="posts_video" class="table table-bordered table-striped" width="100%">
									<thead>
										<tr>
											<th><?php _e('Video', 'viralpress-pro'); ?></th>
											<th><?php _e('Post', 'viralpress-pro'); ?></th>
											<th>&nbsp;</th>
										</tr>
									</thead>
								<tbody></tbody>
							</table>
							<div id="page-video"></div>
						</div>
						<!-- END VIDEOS POSTS -->
						<!-- BEGIN IMAGES POSTS -->
						<div role="tabpanel" class="tab-pane" id="images">
							<table id="posts_images" class="table table-bordered table-striped" width="100%">
									<thead>
										<tr>
											<th><?php _e('Image', 'viralpress-pro'); ?></th>
											<th><?php _e('Post', 'viralpress-pro'); ?></th>
											<th>&nbsp;</th>
										</tr>
									</thead>
								<tbody></tbody>
							</table>
							<div id="page-image"></div>
						</div>
						<!-- END IMAGES POST -->
					</div>
					<!-- END TAB PANEL -->
				</div>
			</div>
			<!-- END RECENT POST OF FB PAGE -->
		</div>
	</div>
</div>
<!-- END SEARCH CONTENT FOR THE SEARCHING PAGE IN FACEBOOK -->

<!-- BIGIN PROCESSING MODAL -->
<div class="modal fade" tabindex="-1" role="dialog" id="pleaseWaitDialog" data-backdrop="static" data-keyboard="false">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" id="close_process" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
				<h1><?php _e('Processing', 'viralpress-pro'); ?>...</h1>
				<div class="viralpress_loader"> </div>
			</div>
			<div class="modal-footer"> </div>
		</div>
	</div>
</div>
<!-- END PROCESSING MODAL -->