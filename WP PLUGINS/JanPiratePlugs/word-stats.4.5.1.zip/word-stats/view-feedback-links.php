<div id="ws-feedback-links" style="clear:both; padding-top: 2em;">
	<img style="float:left; margin-top: -2px; margin-right: 4px;" src="<?php echo plugins_url(); ?>/word-stats/img/pin-blue.png" />
	<?php
		printf( __( 'Feedback, questions, bugs? Send them to the %1$splugin support forum%2$s or %3$semail%2$s the author.', 'word-stats' ), '<a href="http://wordpress.org/tags/word-stats">', '</a>', '<a href="mailto:email@franontanaya.com?subject=Word Stats support">' );
	?>
</div>
