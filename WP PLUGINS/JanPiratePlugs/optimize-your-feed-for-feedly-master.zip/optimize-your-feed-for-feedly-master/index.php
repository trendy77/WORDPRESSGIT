<?php

// Silence is some kind of mineral.