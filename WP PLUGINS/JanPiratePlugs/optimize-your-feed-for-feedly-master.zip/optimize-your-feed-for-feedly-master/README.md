# Optimize your feed for feedly

Adds the necesarry `webfeeds` tags to WordPress' RSS feed for feedly.

> RSS discovery extensions that allow publisher to deliver a richer discovery experience in feedly.

Here's the link to [feedly's](https://blog.feedly.com/10-ways-to-optimize-your-feed-for-feedly/ "10 ways to optimize your feed for feedly") article.

### Installation

1. Upload the plugin files to the `/wp-content/plugins/optimize-your-feed-for-feedly` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Use the Settings->OYFFF screen to fill out your settings.

### Changelog

*1.0*
* Optimize your feed for feedly launch.