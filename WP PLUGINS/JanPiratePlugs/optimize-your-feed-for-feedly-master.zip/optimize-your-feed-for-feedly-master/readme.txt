=== Optimize your feed for feedly ===
Contributors: implenton, FlorianBrinkmann
Tags: rss, feedly
Requires at least: 4.0
Tested up to: 5.4
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

RSS discovery extensions that allow publisher to deliver a richer discovery experience in feedly.

== Description ==

Adds the necesarry `webfeeds` tags to the RSS feed for feedly.

Here's the link to [feedly's](https://blog.feedly.com/10-ways-to-optimize-your-feed-for-feedly/ "10 ways to optimize your feed for feedly") article.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/optimize-your-feed-for-feedly` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Settings->OYFFF screen to fill out your informations

== Changelog ==

= 1.0 =
* Optimize your feed for feedly launch.