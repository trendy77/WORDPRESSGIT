<div class="details-container">
	<div class="details">
		<span class="icon spinner"></span>
		<span class="message">
			<span><?php esc_html_e( 'compressing', 'tiny-compress-images' ) ?></span>
		</span>
	</div>
</div>
