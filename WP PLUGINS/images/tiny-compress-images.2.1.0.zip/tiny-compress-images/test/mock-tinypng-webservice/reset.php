<?php

require 'common.php';
$session = null;
