<?php
require_once( WPTOUCH_DIR . '/core/admin-custom-icons.php' );