<?php
/*
Plugin Name: Delete Duplicate Posts
Plugin Script: delete-duplicate-posts.php
Plugin URI: https://cleverplugins.com
Description: Get rid of duplicate blogposts on your blog! Searches and removes duplicate posts and their post meta tags. You can delete posts, pages and other Custom Post Types enabled on your website.
Version: 4.0.2
Author: cleverplugins.com
Author URI: https://cleverplugins.com
Min WP Version: 3.6
Max WP Version: 4.6

== Changelog ==

= 4.0.2 =
* Fixes problem with cron job not working properly.
* New: Choose interval for automated cron job to run.
* Adds 3 cron interval 10 min, 15 min and 30 minutes to WordPress.
* Minor PHP Notice fix.
* Code cleaning up


= 4.0.1 =
* Added log notes for cron jobs and manual cleaning.
* Added missing screenshots, banners and icons.

= 4.0 =
* Big rewrite, long overdue, many bugs fixed
* NEW: Choose between post types.
* Optional cron job now runs every hour, not every half hour.
* The log was broken, it has now been fixed.
* Removed unused and old code.
* Improved plugin layout.

*/


if (!class_exists('delete_duplicate_posts')) {
	class delete_duplicate_posts {
		var $optionsName 				= 'delete_duplicate_posts_options_v4';
		var $localizationDomain = "delete_duplicate_posts";
		var $options 						= array();

		function __construct(){
			$locale = get_locale();
			$mo = dirname(__FILE__) . "/languages/" . 'delete_duplicate_posts' . "-".$locale.".mo";
			load_plugin_textdomain( 'delete_duplicate_posts', FALSE,  dirname( __FILE__ )  . '/languages/' );
			add_action('admin_head', array(&$this, 'set_custom_help_content'), 1, 2); // loads help tab
			$this->getOptions();
			
			add_action("admin_menu", array(&$this,"admin_menu_link"));
			add_action('admin_enqueue_scripts', array(&$this, 'admin_enqueue_scripts'));
			register_activation_hook(__FILE__,array(&$this,"install")); // TODO - register deactivation hooks
			add_action('admin_head', array(&$this,"admin_register_head"));
			add_action('ddp_cron', array(&$this,"cleandupes"));			

			add_action('cron_schedules', array(&$this,"add_cron_intervals"));		
		}

		function cleandupes($manualrun='0') {

			$this->getOptions();
			// if (!$this->options['ddp_running'] ) {
				$this->options['ddp_running']=TRUE;

				if ($manualrun=='0') {
					$this->log(__('Cron job running.','delete_duplicate_posts'));
				}
				else {
					$this->log(__('Manually cleaning.','delete_duplicate_posts'));
				}

				global $wpdb;
				$table_name = $wpdb->prefix . "posts";	
				$limit=$this->options['ddp_limit'];
				if (!$limit<>'') $limit=10; //defaults to 10!			
				if ($manualrun=='1') $limit=9999;
				$order=$this->options['ddp_keep'];
				if (($order<>'oldest') OR ($order<>'latest')) { // verify default value has been set.
					$this->options['ddp_keep']='oldest';
				}

				if ($order=='oldest') $minmax="MIN(id)";
				if ($order=='latest') $minmax="MAX(id)";
				// get custom post types and loop for query.
				$ddp_pts_arr = $this->options['ddp_pts'];
				if ($ddp_pts_arr) {
					$ddp_pts = '';
					foreach ($ddp_pts_arr as $key => $dpa ) {
						$ddp_pts .= '"'.$dpa.'",';
					}
				}
				else {
					$ddp_pts = '';
				}
				$ddp_pts = rtrim($ddp_pts,',' );

				$query="select bad_rows.ID, bad_rows.post_title, post_type
				from $table_name as bad_rows
				inner join (
				select post_title,id, MIN(id) as min_id
				from $table_name 
				WHERE (
				`post_status` = 'publish'
				AND
				`post_type` in (".$ddp_pts.")
				)
				group by post_title
				having count(*) > 1
				) as good_rows on good_rows.post_title = bad_rows.post_title
				and good_rows.min_id <> bad_rows.id
				and (bad_rows.post_status='publish' OR bad_rows.post_status='draft')
				order by post_title,id
				;
				";

				//var_dump($query);
				$dupes = $wpdb->get_results($query);
				$dupescount = count($dupes); 
				$resultnote='';
				$dispcount=0;
				
				foreach ($dupes as $dupe) {
					$postid=$dupe->ID;

					$title=substr($dupe->post_title,0,35);
					$perma=get_permalink($postid);
					if ($postid<>''){
						$custom_field_keys = get_post_custom_keys($postid);
						foreach ( $custom_field_keys as $key => $value ) {
							delete_post_meta($postid, $key, '');
						}
						$result = wp_delete_post($postid);
						if (!$result) {	
							$this->log(sprintf( __( "Error, problem deleting %s '%d' %s", 'delete_duplicate_posts'), $dupe->post_type, $postid, $perma));	
						}
						else {	
							$dispcount++;
							$this->log(sprintf( __( "Deleted %s '%s' (id: %s) and related post meta data.", 'delete_duplicate_posts'), $dupe->post_type, $title, $postid ));
						}
					}
				} // foreach ($dupes as $dupe)			

				if ($dispcount>0) {
					$this->log(sprintf( __( "A total of %s duplicate posts were deleted.", 'delete_duplicate_posts'), $dispcount));

				}

					// Mail logic...	
				if (($dispcount>0) &&($manualrun=='1') && ($this->options['ddp_statusmail'])) { 

					$adminemail = get_option('admin_email'); // get admins email

					$blogurl = site_url();

					$messagebody = sprintf( __( "Hi Admin, I have deleted <strong>%d</strong> posts on your blog, %s.<br><br><em>You are receiving this e-mail because you have turned on e-mail notifications by the plugin, Delete Duplicate Posts.</em>",'delete_duplicate_posts'), $dispcount, $blogurl);
					
					$messagebody .= "<br>Made by <a href='https://cleverplugins.com' target='_blank'>cleverplugins.com</a>";
					$headers = "From: $blogurl <$adminemail>" . "\r\n";
					$mailstatus = wp_mail($adminemail, __('Deleted Duplicate Posts Status','delete_duplicate_posts'), $messagebody, $headers);		

					if ($mailstatus) {
						$this->log(sprintf( __( "Status email sent to %s.", 'delete_duplicate_posts'), $adminemail));
					}
				}

				$this->options['ddp_running']=FALSE;
		//	}  // if (!$this->options['ddp_running'] )
		}


		function admin_register_head() {

		}

		function add_cron_intervals($schedules) {
			$schedules['10min'] = array(
				'interval' => 600,
				'display' => __('Every 10 minutes','delete_duplicate_posts')
				);
			$schedules['15min'] = array(
				'interval' => 900,
				'display' => __('Every 15 minutes','delete_duplicate_posts')
				);
			$schedules['30min'] = array(
				'interval' => 1800,
				'display' => __('Every 30 minutes','delete_duplicate_posts')
				);
			return $schedules;
		}

		function log($text) {
			global $wpdb;
			$ddp_logtable = $wpdb->prefix . "ddp_log";
			$result = $wpdb->query( $wpdb->prepare( 
				"
				INSERT INTO $ddp_logtable
				( datime, note )
				VALUES ( %s, %s )
				", 
				current_time('mysql'), 
				$text
				) );
			$total = (int) $wpdb->get_var("SELECT COUNT(*) FROM `$ddp_logtable`;");
			if ($total>1000) {
				$targettime = $wpdb->get_var("SELECT `time` from `$ddp_logtable` order by `time` DESC limit 500,1;");
				$query="DELETE from `$ddp_logtable`  where `time` < '$targettime';";
				$success= $wpdb->query ($query);
			}
		}

		function admin_enqueue_scripts() {
			$screen = get_current_screen();
			if (is_object($screen) && ($screen->id == 'tools_page_delete-duplicate-posts') ) {
				wp_enqueue_style('ddpcss', plugins_url('/css/delete-duplicate-posts.css', __FILE__));
			}
		}

		function install () {
			global $wpdb;
			require_once(ABSPATH . '/wp-admin/includes/upgrade.php');
			$table_name = $wpdb->prefix . "ddp_log";
			if($wpdb->get_var("show tables like '$table_name'") != $table_name) {
				$sql = "CREATE TABLE $table_name (
				id bigint(20) NOT NULL AUTO_INCREMENT,
				datime timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
				note tinytext NOT NULL,
				PRIMARY KEY (id)
				);";
				dbDelta($sql);
			}   
			$this->saveAdminOptions();
			wp_clear_scheduled_hook('ddp_cron'); // deactivate it just in case it was turned on.
			$this->log(__( "Plugin activated.", 'delete_duplicate_posts'));
		}	

		function getOptions() {
			if (get_option('delete_duplicate_posts_options')) {
				delete_option('delete_duplicate_posts_options'); // Clean old version to allow default values to be set.
			}

			if (!$theOptions = get_option($this->optionsName)) {
				$theOptions = array('ddp_running'=>'false');
				update_option($this->optionsName, $theOptions);
			}
			$this->options = $theOptions;

		}
		
		function saveAdminOptions(){
			return update_option($this->optionsName, $this->options);
		}
		
		function admin_menu_link() {
			add_management_page('Delete Duplicate Posts', 'Delete Duplicate Posts', 'manage_options', basename(__FILE__), array(&$this,'admin_options_page'));
			add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), array(&$this, 'filter_plugin_actions'), 10, 2 ); // Adds the Settings link to the plugin page
		}

		function filter_plugin_actions($links, $file) {
			$settings_link = '<a href="tools.php?page=' . basename(__FILE__) . '">' . __('Settings','delete_duplicate_posts') . '</a>';
			array_unshift( $links, $settings_link ); // before other links
			return $links;
		}

		function set_custom_help_content() {
			$screen = get_current_screen();

			if ($screen->id == 'tools_page_delete-duplicate-posts') {
				$screen->add_help_tab(
					array(
						'id'      => 'ddp_help',
						'title'   => __('Usage and FAQ','delete_duplicate_posts'),
						'content' => "
						<h4>".__('What does this plugin do?','delete_duplicate_posts')."</h4>		
						<p>".__('Helps you clean duplicate posts from your blog. The plugin checks for blogposts on your blog with the same title.','delete_duplicate_posts')."</p>
						<p>".__("It can run automatically via WordPress's own internal CRON-system, or you can run it automatically.",'delete_duplicate_posts')."</p>	
						<p>".__('It also has a nice feature that can send you an e-mail when Delete Duplicate Posts finds and deletes something (if you have turned on the CRON feature).','delete_duplicate_posts')."</p>
						<h4>".__('Help! Something was deleted that was not supposed to be deleted!','delete_duplicate_posts')."</h4>	
						<p>".__('I am sorry for that, I can only recommend you restore the database you took just before you ran this plugin.','delete_duplicate_posts')."</p>
						<p>".__('If you run this plugin, manually or automatically, it is at your OWN risk!','delete_duplicate_posts')."</p>
						<p>".__('I have done my best to avoid deleting something that should not be deleted, but if it happens, there is nothing I can do to help you.','delete_duplicate_posts')."</p>
						<p><a href='https://cleverplugins.com' target='_blank'>cleverplugins.com</a>.</p>"
						)
					);			
			}
		}


		function admin_options_page() { 

				//echo "<pre>".print_r($_POST,true)."</pre>";

		// DELETE NOW
			if ( (isset($_POST['deleteduplicateposts_delete'] ) ) AND (isset($_POST['_wpnonce'] ) ) )  {
				if  (wp_verify_nonce($_POST['_wpnonce'], 'ddp-clean-now')){
				$this->cleandupes(1); // use the value 1 to indicate it is being run manually.
			}
		}

		// RUN NOW!!
		if(isset($_POST['ddp_runnow'])){
			if (! wp_verify_nonce($_POST['_wpnonce'], 'ddp-update-options') ) die(__('Whoops! Some error occured, try again, please!','delete_duplicate_posts')); 
		}


		// SAVING OPTIONS
		if  (isset($_POST['delete_duplicate_posts_save'])){
			if (! wp_verify_nonce($_POST['_wpnonce'], 'ddp-update-options') ) {
				die(__('Whoops! There was a problem with the data you posted. Please go back and try again.','delete_duplicate_posts'));
			}

				//echo "<pre>".print_r($_POST,true)."</pre>"; // debug
				$posttypes = array();

				if (isset($_POST['ddp_pts'])) {
					$optionArray = $_POST['ddp_pts'];
					for ($i=0; $i<count($optionArray); $i++) {
						$posttypes[] = $optionArray[$i];
					}
				}

				$this->options['ddp_enabled'] = ($_POST['ddp_enabled']=='on')?true:false;
				$this->options['ddp_statusmail'] = ( (isset($_POST['ddp_statusmail'])) && ($_POST['ddp_statusmail']=='on'))?true:false;
				$this->options['ddp_schedule'] = esc_sql($_POST['ddp_schedule']);		
				$this->options['ddp_keep'] = esc_sql($_POST['ddp_keep']);		
				$this->options['ddp_pts'] = esc_sql($posttypes);		
				$this->options['ddp_limit'] = $_POST['ddp_limit'];
				if (isset($this->options['ddp_enabled'])) {
					wp_clear_scheduled_hook('ddp_cron');
					$interval = $this->options['ddp_schedule'];
					if (!$interval) $interval = 'hourly';
					wp_schedule_event(time(), $interval, 'ddp_cron');
					$nextscheduled = wp_next_scheduled('ddp_cron');
				}				
				$this->saveAdminOptions();
				echo '<div class="updated fade"><p>'.__('Your changes were successfully saved.','delete_duplicate_posts').'</p></div>';
			}

		// CLEARING THE LOG
			if(isset($_POST['ddp_clearlog'])) {
				if (! wp_verify_nonce($_POST['_wpnonce'], 'ddp_clearlog_nonce') ) die(__('Whoops! Some error occured, try again, please!','delete_duplicate_posts')); 
				global $wpdb;
				$table_name_log = $wpdb->prefix . "ddp_log";	
				$wpdb->query ("TRUNCATE `$table_name_log`;");
				echo '<div class="updated"><p>'.__('The log was cleared.','delete_duplicate_posts').'</p></div>';
				unset($wpdb);
			}			


			global $wpdb;


			$table_name = $wpdb->prefix . "posts";	

			$pluginfo=get_plugin_data(__FILE__);
			$version=$pluginfo['Version'];	
			$name=$pluginfo['Name'];
			?>

			<div class="wrap">    
				<div style="float:right;">
					<a href="https://cleverplugins.com" target="_blank"><img src='<?php echo plugin_dir_url(__FILE__); ?>/cleverpluginslogo.png'></a>
				</div>
				<h2>Delete Duplicate Posts v <?php echo $version; ?></h2>
				<div id="dashboard">
					<?php
					if ($this->options['ddp_enabled'] ) {
						$nextscheduled = wp_next_scheduled('ddp_cron');
						if (!$nextscheduled<>'') { // plugin active, but the cron needs to be activated also..
							wp_clear_scheduled_hook('ddp_cron');
							$interval = $this->options['ddp_schedule'];
							if (!$internal) $interval = 'hourly';
							wp_schedule_event(time(), $internal, 'ddp_cron');
							$nextscheduled = wp_next_scheduled('ddp_cron');
						}
					}
					else {
						wp_clear_scheduled_hook('ddp_cron');
					}

					// get custom post types and loop for queary.
					$ddp_pts_arr = $this->options['ddp_pts'];
					if ($ddp_pts_arr) {
						$ddp_pts = '';
						foreach ($ddp_pts_arr as $key => $dpa ) {
							$ddp_pts .= '"'.$dpa.'",';
						}
					}
					else {
						$ddp_pts = '';
					}

					$ddp_pts = rtrim($ddp_pts,',' );

					$query="select bad_rows.ID, bad_rows.post_title, post_type
					from $table_name as bad_rows
					inner join (
					select post_title,id, MIN(id) as min_id
					from $table_name 
					WHERE (
					`post_status` = 'publish'
					AND
					`post_type` in (".$ddp_pts.")
					)
					group by post_title
					having count(*) > 1
					) as good_rows on good_rows.post_title = bad_rows.post_title
					and good_rows.min_id <> bad_rows.id
					and (bad_rows.post_status='publish' OR bad_rows.post_status='draft')
					order by post_title,id
					;
					";

					$dupes = $wpdb->get_results($query);
					$dupescount = count($dupes); 	

					if ($dupescount) {

						?>
						<div class="statusdiv"> 
							<h3><?php
								echo sprintf( __('I have discovered %d duplicate posts', 'delete_duplicate_posts'), $dupescount); ?></h3>
								<?php
								$plugurl = WP_CONTENT_URL . '/plugins/' .plugin_basename(__FILE__) ;	
								?>
								<table class="widefat post" cellspacing="0">
									<thead>
										<tr>
											<th><?php _e('ID','delete_duplicate_posts'); ?></th>
											<th><?php _e('Title','delete_duplicate_posts'); ?></th>
											<th><?php _e('Post Type','delete_duplicate_posts'); ?></th>
										</tr>
									</thead>
									<tbody>
										<?php
										foreach ($dupes as $dupe) {
											$postid=$dupe->ID;
											$title=substr($dupe->post_title,0,120);
											echo "<tr>
											<td>".$postid."</td>
											<td><a href='".get_permalink($postid)."' target='_blank'>".$title."</a>
											</td>
											<td>".$dupe->post_type."</td>
										</tr>";
									}
									?>
								</tbody>
							</table>
							<p class="warning"><?php _e('We recommend you always make a backup before running this tool. Changes are permanent!','delete_duplicate_posts');?></p>
							<form method="post" id="ddp_runcleannow">
								<?php wp_nonce_field('ddp-clean-now'); ?>
								<p align="center"><input type="submit" name="deleteduplicateposts_delete" class="button-primary" value="<?php _e('Delete all duplicates','delete_duplicate_posts'); ?>" /></p>
							</form>
						</div>
						<hr>
						<?php
					} // if ($dupescount)
				else { // no dupes found!
					?>
					<div class="statusdiv"> 
						<h3><?php _e('I have just checked, and you have no duplicate posts.','delete_duplicate_posts');?></h3>
						<p>
							<?php
							$nextscheduled = wp_next_scheduled('ddp_cron');
							
							if ($nextscheduled) echo '<p class="cronstatus center">'.__('You have enabled CRON, so I am running on automatic. I will take care of everything...','delete_duplicate_posts').'</p>';

							if ($nextscheduled) {
								echo '<p class="center">'.sprintf( __( "Next automated check %s. Current time %s", 'delete_duplicate_posts'), date_i18n(get_option('date_format').' '.get_option('time_format'),$nextscheduled), date_i18n(get_option('date_format').' '.get_option('time_format'),time()) ).'</p>';
							}
							?>
						</p>
					</div>
					<?php
				}
				?>
			</div>			
			<div id="configuration">
				<h3><?php _e('Settings', 'delete_duplicate_posts'); ?></h3>  

				<form method="post" id="delete_duplicate_posts_options">
					<?php wp_nonce_field('ddp-update-options'); ?>
					<table width="100%" cellspacing="2" cellpadding="5" class="form-table">

						<tr valign="top"> 
							<th><label for="ddp_enabled"><?php _e('Which post types?:', 'delete_duplicate_posts'); ?></label></th>
							<td>
								<?php
								$args = array(
									'public'   => true,
									'_builtin' => true
									);
								$output = 'names'; // names or objects, note names is the default
								$operator = 'and'; // 'and' or 'or'
								$post_types = get_post_types( $args, $output, $operator ); 
								$checked_post_types = $this->options['ddp_pts'];
								if ($post_types) {
									?>
									<ul class="radio">
										<?php
										$step=0;
										foreach ($post_types as $pt) {
											$checked = array_search($pt,$checked_post_types,true);
											?>
											<li>
												<input type="checkbox" name="ddp_pts[]" id="ddp_pt-<?php echo $step;?>" value="<?php echo $pt; ?>" <?php if ($checked !== false) echo ' checked';?>/>
												<label for="ddp_pt-<?php echo $step; ?>"><?php echo $pt; ?></label>
											</li>
											<?php
											$step++;
										}
										?>
									</ul>
									<?php
								}
								?>
							</td>
						</tr>

						<tr valign="top"> 
							<th><label for="ddp_enabled"><?php _e('Enable automatic deletion?:', 'delete_duplicate_posts'); ?></label></th><td><input type="checkbox" id="ddp_enabled" name="ddp_enabled" <?php if ($this->options['ddp_enabled']==true) echo 'checked="checked"' ?>>
							<p><em><?php _e('Clean duplicates automatically. Runs every hour.', 'delete_duplicate_posts'); ?></em></p>
						</td>
					</tr>


					<tr>
						<th><label for="ddp_schedule"><?php _e('How often?:', 'delete_duplicate_posts'); ?></label></th><td>

						<select name="ddp_schedule" id="ddp_schedule">
							<?php
							$schedules = wp_get_schedules();
							if ($schedules) {
								foreach ($schedules as $key => $sch) {
									?>
									<option value="<?php echo $key; ?>" <?php if ($this->options['ddp_schedule']==$key) echo 'selected="selected"'; ?>><?php echo $sch['display']; ?></option>
									<?php
								}
							}
							?>
						</select>
						<p><em><?php _e('How often should the cron job run?', 'delete_duplicate_posts'); ?></em></p>
					</td>
				</tr> 


				<tr>
					<th><label for="ddp_keep"><?php _e('Delete which posts?:', 'delete_duplicate_posts'); ?></label></th><td>

					<select name="ddp_keep" id="ddp_keep">
						<option value="oldest" <?php if ($this->options['ddp_keep']=='oldest') echo 'selected="selected"'; ?>><?php _e('Keep oldest post','delete_duplicate_posts'); ?></option>
						<option value="latest" <?php if ($this->options['ddp_keep']=='latest') echo 'selected="selected"'; ?>><?php _e('Keep latest post','delete_duplicate_posts'); ?></option>
					</select>


					<p><em><?php _e('Keep the oldest or the latest version of duplicates? Default is keeping the oldest, and deleting any subsequent duplicate posts', 'delete_duplicate_posts'); ?></em></p>
				</td>
			</tr> 
			<tr>
				<th><label for="ddp_statusmail"><?php _e('Send status mail?:', 'delete_duplicate_posts'); ?></label></th><td><input type="checkbox" id="ddp_statusmail" name="ddp_statusmail" <?php if ($this->options['ddp_statusmail']==true) echo 'checked="checked"'; ?>>
				<p><em><?php _e('Sends a status email if duplicates have been found.', 'delete_duplicate_posts'); ?></em></p>
			</td>
		</tr> 
		<tr valign="top"> 
			<th><label for="ddp_limit"><?php _e('Delete at maximum :', 'delete_duplicate_posts'); ?></label></th><td><select name="ddp_limit">
			<?php
			for($x = 1; $x <= 8; $x++) {
				$val=($x*25);
				echo "<option value='$val' ";
				if ($this->options['ddp_limit']==$val) echo "selected"; 
				echo ">$val</option>";
			}
			?> 
		</select>
		<?php _e('duplicates.', 'delete_duplicate_posts'); ?>
		<p><em><?php _e('Setting a limit is a good idea, especially if your site is on a busy server.', 'delete_duplicate_posts'); ?></em></p>
	</td>
</tr>
<th colspan=2><input type="submit" class="button-primary" name="delete_duplicate_posts_save" value="<?php _e('Save Settings', 'delete_duplicate_posts'); ?>" /></th>
</tr>

</table>

</form>
</div>


<div id="log">

	<h3><?php _e('The Log', 'delete_duplicate_posts'); ?></h3>
	<textarea rows="16" class="large-text" name="ddp_log" id="ddp_log"><?php
		$table_name_log = $wpdb->prefix . "ddp_log";	
		$query = "SELECT * FROM `".$table_name_log."` order by `id` ASC";
		$loghits = $wpdb->get_results($query, ARRAY_A);
		if ($loghits){
			foreach ($loghits as $hits) {
				echo $hits['datime'].' '.$hits['note']."\n";
			}
		}		

		?></textarea>
		<p>
			<form method="post" id="ddp_clearlog">
				<?php wp_nonce_field('ddp_clearlog_nonce'); ?>

				<input class="button-secondary" type="submit" name="ddp_clearlog" value="<?php _e('Reset log','delete_duplicate_posts'); ?>" />
			</form>
		</p> 

	</div>
</div>




<?php
}


	} //End Class
} 

if (class_exists('delete_duplicate_posts')) {
	$delete_duplicate_posts_var = new delete_duplicate_posts();
}
?>