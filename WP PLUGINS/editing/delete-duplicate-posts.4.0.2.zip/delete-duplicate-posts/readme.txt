=== Delete Duplicate Posts ===
Contributors: lkoudal
Tags: delete duplicate posts, delete duplicate,
Donate link: https://cleverplugins.com
Requires at least: 3.6
Tested up to: 4.6
Stable tag: 4.0.2

Get rid of duplicate blogposts on your blog! 

== Description ==
This plugin searches and removes duplicate posts and their meta data. You can change in the settings how many at a time and if the plugin should run automatically every hour.

You can delete posts, pages and other Custom Post Types enabled on your website.

Read more on the [plugin page](https://cleverplugins.com/delete-duplicate-posts).

== Installation ==
1. Upload the delete-duplicate-posts folder to the /wp-content/plugins/ directory
2. Activate the Delete Duplicate Posts plugin through the \'Plugins\' menu in WordPress
3. Use the plugin by going to Tools -> Delete Duplicate Posts

== Frequently Asked Questions ==
= Should I take a backup before using this tool? =
Yes! You should always take a backup before deleting posts or pages on your website.

= What happens if it deletes something I do not want to delete? =
You should restore the backup you took of your website before you ran this tool.


== Screenshots ==
1. Duplicate posts were found
2. Details in the log

== Changelog ==

= 4.0.2 =
* Fixes problem with cron job not working properly.
* New: Choose interval for automated cron job to run.
* Adds 3 cron interval 10 min, 15 min and 30 minutes to WordPress.
* Minor PHP Notice fix.
* Code cleaning up

= 4.0.1 =
* Added log notes for cron jobs and manual cleaning.
* Added missing screenshots, banners and icons.

= 4.0 =
* Big rewrite, long overdue, many bugs fixed
* NEW: Choose between post types.
* Optional cron job now runs every hour, not every half hour.
* The log was broken, it has now been fixed.
* Removed unused and old code.
* Improved plugin layout.

= 3.1 = 
* Fix for deleting any dupes but posts - ie. not menu items :-/
* Fix for PHP warnings.
* Fix for old user capabilities code.

= 3.0 = 
* Code refactoring and updates - Basically rewrote most of the plugin.
* Removed link in footer.
* Removed dashboard widget.
* Internationalization - Now plugin can be translated
* Danish language file added.

= 2.1 =
* Bugfixes

= 2.0.6 =
* Bugfix: Problem with the link-donation logic. Hereby fixed. 

= 2.0.5 =
* Bugfix: Could not access the settings page from the Plugins page. 
* Ads are no longer optional. Sorry about that :-)
* Changes to the amount of duplicates you can delete using CRON.


= 2.0.4 =
* Bugfix : A minor speed improvement.

= 2.0.3 =
* Bugfix : Minor logic error fixed.

= 2.0.2 =
* Bugfix : Now actually deletes duplicate posts when clicking the button manually.. Doh...


= 2.0 =
* Design interface updated
+ New automatic CRON feature as per many user requests
+ Optional: E-mail notifications


= 1.3.1 =
* Fixes problem with dashboard widget. Thanks to Derek for pinpointing the error.

= 1.3 =
* Ensures all post meta for the deleted blogposts are also removed...

= 1.1 =
* Uses internal delete function, which also cleans up leftover meta-data. Takes a lot more time to complete however and might time out on some hosts.

= 1.0 =
* First release

== Upgrade Notice ==
Major rewrite that fixes many bugs and adds new features!