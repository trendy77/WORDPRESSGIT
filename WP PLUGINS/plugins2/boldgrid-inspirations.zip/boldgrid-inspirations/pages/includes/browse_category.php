<div class='wrap'>
	<div class='plugin-card'>
		<div class='plugin-card-top'>
			<div id='categories-left'></div>
			<div id='categories-right'></div>
			<div name='imhwpb-categories' id='imhwpb-categories'></div>
			<!--
			<div id='category-select'>
				<span><?php _e('Choose Your Category','boldgrid-inspirations'); ?></span>
			</div>
			-->
		</div>
		<div class='plugin-card-bottom'>
			<div class='column-updated'>
				<a class="button button-primary sub-category-select"
					disabled='disabled'>Select</a>
			</div>
		</div>
	</div>
</div>
