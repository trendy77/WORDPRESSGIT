<div id="choose_page_set" class='bold-grid-enabled fluid-container'>
	<h1><?php _e('Step 3: Choose Your Pages','boldgrid-inspirations'); ?></h1>

	<div class='row'>

		<div class="col-lg-3 col-md-4 col-sm-5 plugin-card">
			<div name='choose_your_page_set' id='choose_your_page_set'
				class='page-selection-preview plugin-card-top'></div>
		</div>

		<div class="col-lg-9 col-md-8  col-sm-7">
			<div name='page_set_preview' id='page_set_preview'
				class="page-selection-preview boldgrid-loading"><?php _e('It looks like you have not yet selected a theme!','boldgrid-inspirations'); ?></div>
		</div>


	</div>
</div>
