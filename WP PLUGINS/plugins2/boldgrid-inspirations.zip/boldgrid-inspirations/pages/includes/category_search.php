<?php

/**
 * ****************************************************************************
 * DEPRECATED
 * ****************************************************************************
 * <h3>Search</h3>
 *
 * <form id='category_search'>
 * <input id="category-search-input" name="s" value="" type="search"
 * autocomplete="off"> <input name="" id="search-submit"
 * class="button button-secondary" value="Search" type="submit">
 * </form>
 *
 * <?php
 * if (isset($_GET['channels']) && $_GET['channels'] == 'all') { ?>
 * <br>
 * <div><label><input type="checkbox" name="candidate">Display Candidate Themes (Internal Only)</label></div>
 * <div><label><input type="checkbox" name="candidate_pages">Display Candidate Pages (Internal Only)</label></div>
 * <?php } ?>
 *
 * <div id='category_search_results'></div>
 *
 * <hr />
 */
?>
