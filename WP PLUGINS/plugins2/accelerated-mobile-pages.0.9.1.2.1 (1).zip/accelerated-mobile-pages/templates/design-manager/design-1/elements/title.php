<header class="amp-wp-article-header ampforwp-title">
	<h1 class="amp-wp-title"><?php echo wp_kses_data( $this->get( 'post_title' ) ); ?></h1>
</header>
