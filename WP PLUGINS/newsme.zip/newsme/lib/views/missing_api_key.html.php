<div class="updated newsatme-updated" style="padding: 0; margin: 0; border: none; background: none; clear: both;">
	<div class="newsatme-activate" style="margin: 20px 0;">
		<a href="<?php echo $link; ?>" class="newsatme-button-container">
				<div class="newsatme-button"><?php _e('Activate your News@me account', 'wpnewsatme'); ?></div>
			</a>
	<div class="newsatme-button-description"><?php _e('<strong>Almost done</strong> - Activate your account and start converting your occasional visitors into regular readers today.', 'wpnewsatme'); ?></div>
	</div>
</div>
