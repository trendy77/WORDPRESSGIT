<div class="error"> 
  <p>Error connecting to News@me. Please check for your API key to be correct.</p>
</div>
