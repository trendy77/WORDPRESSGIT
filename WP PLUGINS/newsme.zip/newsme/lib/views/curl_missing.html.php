<div class="updated"> 
  <p>
    <?php _e('Please ask your hosting provider to install', 'wpnewsatme'); ?>
    <a href="http://www.php.net/manual/en/book.curl.php">Curl functions</a>.
  </p>
</div>
