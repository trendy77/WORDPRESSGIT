<div class="updated" >
  <p><?php _e('News@me was not able to save your post, please save it again.', 'wpnewsatme'); ?></p>
</div>
