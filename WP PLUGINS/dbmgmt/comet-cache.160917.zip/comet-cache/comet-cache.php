<?php
/*
Version: 160917
Text Domain: comet-cache
Plugin Name: Comet Cache
Network: true

Author: WebSharks, Inc.
Author URI: http://websharks-inc.com/

Plugin URI: http://cometcache.com/
Description: Comet Cache is an advanced WordPress caching plugin inspired by simplicity.
*/
if (!defined('WPINC')) {
    exit('Do NOT access this file directly: '.basename(__FILE__));
}
require_once dirname(__FILE__).'/plugin.php';
