<?php
include_once('bootstrap.php');

$mainWP->mainwp_cronpingchilds_action();