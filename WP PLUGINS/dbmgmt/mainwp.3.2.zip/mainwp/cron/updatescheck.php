<?php
include_once('bootstrap.php');

$mainWP->mainwp_cronupdatescheck_action();