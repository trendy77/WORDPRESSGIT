<?php
include_once('bootstrap.php');

$mainWP->mainwp_cronstats_action();