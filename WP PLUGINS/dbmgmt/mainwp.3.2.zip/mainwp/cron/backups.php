<?php
include_once('bootstrap.php');

$mainWP->mainwp_cronbackups_action();